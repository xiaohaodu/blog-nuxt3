import { b as buildAssetsURL } from './renderer.mjs';
import { ref, mergeProps, useSSRContext } from 'vue';
import { _ as _export_sfc, g as useNuxtApp } from './server.mjs';
import { ssrRenderAttrs } from 'vue/server-renderer';
import Phaser from 'phaser';
import 'vue-bundle-renderer/runtime';
import 'h3';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@vue/shared';
import 'lodash-unified';
import '@vueuse/core';

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
const frames = {
  ball1: {
    frame: {
      x: 452,
      y: 2,
      w: 22,
      h: 22
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 22,
      h: 22
    },
    sourceSize: {
      w: 22,
      h: 22
    }
  },
  ball2: {
    frame: {
      x: 476,
      y: 2,
      w: 22,
      h: 22
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 22,
      h: 22
    },
    sourceSize: {
      w: 22,
      h: 22
    }
  },
  blue1: {
    frame: {
      x: 386,
      y: 2,
      w: 64,
      h: 32
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 64,
      h: 32
    },
    sourceSize: {
      w: 64,
      h: 32
    }
  },
  blue2: {
    frame: {
      x: 108,
      y: 53,
      w: 64,
      h: 32
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 64,
      h: 32
    },
    sourceSize: {
      w: 64,
      h: 32
    }
  },
  button: {
    frame: {
      x: 2,
      y: 2,
      w: 190,
      h: 49
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 190,
      h: 49
    },
    sourceSize: {
      w: 190,
      h: 49
    }
  },
  buttonOver: {
    frame: {
      x: 194,
      y: 2,
      w: 190,
      h: 49
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 190,
      h: 49
    },
    sourceSize: {
      w: 190,
      h: 49
    }
  },
  green1: {
    frame: {
      x: 2,
      y: 79,
      w: 64,
      h: 32
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 64,
      h: 32
    },
    sourceSize: {
      w: 64,
      h: 32
    }
  },
  green2: {
    frame: {
      x: 174,
      y: 53,
      w: 64,
      h: 32
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 64,
      h: 32
    },
    sourceSize: {
      w: 64,
      h: 32
    }
  },
  paddle1: {
    frame: {
      x: 386,
      y: 36,
      w: 104,
      h: 24
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 104,
      h: 24
    },
    sourceSize: {
      w: 104,
      h: 24
    }
  },
  paddle2: {
    frame: {
      x: 2,
      y: 53,
      w: 104,
      h: 24
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 104,
      h: 24
    },
    sourceSize: {
      w: 104,
      h: 24
    }
  },
  particle1: {
    frame: {
      x: 492,
      y: 26,
      w: 10,
      h: 10
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 10,
      h: 10
    },
    sourceSize: {
      w: 10,
      h: 10
    }
  },
  particle2: {
    frame: {
      x: 492,
      y: 38,
      w: 10,
      h: 10
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 10,
      h: 10
    },
    sourceSize: {
      w: 10,
      h: 10
    }
  },
  particle3: {
    frame: {
      x: 68,
      y: 79,
      w: 20,
      h: 19
    },
    rotated: false,
    trimmed: true,
    spriteSourceSize: {
      x: 0,
      y: 1,
      w: 20,
      h: 19
    },
    sourceSize: {
      w: 20,
      h: 21
    }
  },
  purple1: {
    frame: {
      x: 240,
      y: 53,
      w: 64,
      h: 32
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 64,
      h: 32
    },
    sourceSize: {
      w: 64,
      h: 32
    }
  },
  purple2: {
    frame: {
      x: 306,
      y: 53,
      w: 64,
      h: 32
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 64,
      h: 32
    },
    sourceSize: {
      w: 64,
      h: 32
    }
  },
  red1: {
    frame: {
      x: 372,
      y: 62,
      w: 64,
      h: 32
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 64,
      h: 32
    },
    sourceSize: {
      w: 64,
      h: 32
    }
  },
  red2: {
    frame: {
      x: 438,
      y: 62,
      w: 64,
      h: 32
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 64,
      h: 32
    },
    sourceSize: {
      w: 64,
      h: 32
    }
  },
  silver1: {
    frame: {
      x: 90,
      y: 87,
      w: 64,
      h: 32
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 64,
      h: 32
    },
    sourceSize: {
      w: 64,
      h: 32
    }
  },
  silver2: {
    frame: {
      x: 156,
      y: 87,
      w: 64,
      h: 32
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 64,
      h: 32
    },
    sourceSize: {
      w: 64,
      h: 32
    }
  },
  yellow1: {
    frame: {
      x: 222,
      y: 87,
      w: 64,
      h: 32
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 64,
      h: 32
    },
    sourceSize: {
      w: 64,
      h: 32
    }
  },
  yellow2: {
    frame: {
      x: 288,
      y: 87,
      w: 64,
      h: 32
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 64,
      h: 32
    },
    sourceSize: {
      w: 64,
      h: 32
    }
  }
};
const meta = {
  app: "http://www.codeandweb.com/texturepacker",
  version: "1.0",
  image: "breakout.png",
  format: "RGBA8888",
  size: {
    w: 504,
    h: 121
  },
  scale: "1",
  smartupdate: "$TexturePacker:SmartUpdate:001f51c9029c40bfd47dffb21081606f:e188858ff10f5876d9b056ceae3435f7:aa94e37632703bccd6a813800bf3159a$"
};
const assetsJson = {
  frames,
  meta
};
const assets = "" + buildAssetsURL("breakout.cfc50a67.png");
class Game extends Phaser.Scene {
  constructor() {
    super(...arguments);
    __publicField(this, "bricks");
    __publicField(this, "paddle");
    __publicField(this, "ball");
  }
  preload() {
    this.load.atlas("assets", assets, assetsJson);
  }
  create() {
    this.physics.world.setBoundsCollision(true, true, true, false);
    this.bricks = this.physics.add.staticGroup({
      key: "assets",
      frame: ["blue1", "red1", "green1", "yellow1", "silver1", "purple1"],
      frameQuantity: 10,
      gridAlign: { width: 10, height: 6, cellWidth: 64, cellHeight: 32, x: 112, y: 100 }
    });
    this.ball = this.physics.add.image(400, 500, "assets", "ball1").setCollideWorldBounds(true).setBounce(1);
    this.ball.setData("onpaddle", true);
    this.paddle = this.physics.add.image(400, 550, "assets", "paddle1").setImmovable();
    this.physics.add.collider(this.ball, this.bricks, this.hitBrick, null, this);
    this.physics.add.collider(this.ball, this.paddle, this.hitpaddle, null, this);
    this.input.on("pointermove", (pointer) => {
      this.paddle.x = Phaser.Math.Clamp(pointer.x, 52, 748);
      if (this.ball.getData("onpaddle")) {
        this.ball.x = this.paddle.x;
      }
    }, this);
    this.input.on("pointerup", (pointer) => {
      if (this.ball.getData("onpaddle")) {
        this.ball.setVelocity(-75, -300);
        this.ball.setData("onpaddle", false);
      }
    }, this);
  }
  update() {
    if (this.ball.y > 600) {
      this.resetball();
    }
  }
  //小球与砖头的碰撞
  hitBrick(ball, brick) {
    brick.disableBody(true, true);
    if (this.bricks.countActive() === 0) {
      this.resetLevel();
    }
  }
  //得新开始
  resetball() {
    this.ball.setVelocity(0);
    this.ball.setPosition(this.paddle.x, 500);
    this.ball.setData("onpaddle", true);
  }
  //新的一个级别
  resetLevel() {
    this.resetball();
    this.bricks.children.each((brick) => {
      brick.enableBody(false, 0, 0, true, true);
    });
  }
  //小球与托盘的碰撞
  hitpaddle(ball, paddle) {
    let diff = 0;
    if (this.ball.x < this.paddle.x) {
      diff = this.paddle.x - this.ball.x;
      this.ball.setVelocityX(-10 * diff);
    } else if (this.ball.x > this.paddle.x) {
      diff = this.ball.x - this.paddle.x;
      this.ball.setVelocityX(10 * diff);
    } else {
      this.ball.setVelocityX(2 + Math.random() * 8);
    }
  }
}
const _sfc_main = {
  __name: "breakout",
  __ssrInlineRender: true,
  setup(__props) {
    const breakout2 = ref(null);
    useNuxtApp();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        ref_key: "breakout",
        ref: breakout2,
        id: "breakout"
      }, _attrs))} data-v-b791bb86></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/game/breakout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const breakout = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-b791bb86"]]);

export { breakout as default };
//# sourceMappingURL=breakout-da100f18.mjs.map
