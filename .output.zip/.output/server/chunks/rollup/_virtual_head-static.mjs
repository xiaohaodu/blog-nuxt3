const _virtual__headStatic = {"headTags":"<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, shrink-to-fit=no\">\n<meta name=\"baidu-site-verification\" content=\"codeva-JXLMMF0sXP\">\n<meta name=\"referrer\" content=\"strict-origin-when-cross-origin\">\n<link rel=\"icon\" type=\"image/x-icon\" href=\"/favicon.ico\">\n<script src=\"/baidu-analytics.js\"></script>","bodyTags":"","bodyTagsOpen":"","htmlAttrs":" lang=\"zh-CN\"","bodyAttrs":""};

export { _virtual__headStatic as default };
//# sourceMappingURL=_virtual_head-static.mjs.map
