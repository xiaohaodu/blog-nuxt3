const kingandpigs_vue_vue_type_style_index_0_scoped_7a00f9c0_lang = "#kingAndPigs[data-v-7a00f9c0]{height:100vh;overflow:hidden;text-align:center;width:100vw}";

const kingandpigsStyles_fb201ac3 = [kingandpigs_vue_vue_type_style_index_0_scoped_7a00f9c0_lang];

export { kingandpigsStyles_fb201ac3 as default };
//# sourceMappingURL=kingandpigs-styles.fb201ac3.mjs.map
