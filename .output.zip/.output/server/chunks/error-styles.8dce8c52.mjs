const error_vue_vue_type_style_index_0_scoped_5f98a8f6_lang = ".NotFound[data-v-5f98a8f6]{background-color:#ffe4ea;height:100vh;overflow:hidden;width:100vw}.NotFound>img[data-v-5f98a8f6]{display:block;height:60vh;margin:0 auto}.NotFound .tip[data-v-5f98a8f6]{font-size:42px;font-weight:600;margin-bottom:15px;text-align:center}";

const errorStyles_8dce8c52 = [error_vue_vue_type_style_index_0_scoped_5f98a8f6_lang];

export { errorStyles_8dce8c52 as default };
//# sourceMappingURL=error-styles.8dce8c52.mjs.map
