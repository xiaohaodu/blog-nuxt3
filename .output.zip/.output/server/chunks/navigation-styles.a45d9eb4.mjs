const navigation_vue_vue_type_style_index_0_scoped_db932b2b_lang = "#nav[data-v-db932b2b]{height:60px;position:fixed;top:0;width:100vw;z-index:2}#nav a[data-v-db932b2b]{cursor:pointer;display:flex;margin:auto 2vw;overflow:hidden;text-decoration:none;text-overflow:clip;white-space:nowrap}#nav .el-menu-item[data-v-db932b2b]{padding-left:2vw;padding-right:2vw}#nav[data-v-db932b2b] .el-sub-menu .el-sub-menu__title{padding-left:2vw;padding-right:calc(10px + 2vw)}#nav[data-v-db932b2b] .el-sub-menu .el-sub-menu__icon-arrow{right:1.2vw}#nav[data-v-db932b2b] +div{height:calc(100vh - 60px);margin-top:60px}";

const navigationStyles_a45d9eb4 = [navigation_vue_vue_type_style_index_0_scoped_db932b2b_lang];

export { navigationStyles_a45d9eb4 as default };
//# sourceMappingURL=navigation-styles.a45d9eb4.mjs.map
