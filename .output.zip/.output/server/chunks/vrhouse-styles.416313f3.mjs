const vrhouse_vue_vue_type_style_index_0_scoped_9c2e4ade_lang = "#container[data-v-9c2e4ade]{height:100vh;overflow:hidden;width:100vw}";

const vrhouseStyles_416313f3 = [vrhouse_vue_vue_type_style_index_0_scoped_9c2e4ade_lang];

export { vrhouseStyles_416313f3 as default };
//# sourceMappingURL=vrhouse-styles.416313f3.mjs.map
