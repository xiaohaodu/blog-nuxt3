import { defineEventHandler, getQuery } from 'h3';
import fs from 'fs';

const readblog = defineEventHandler((event) => {
  return new Promise((resolve, reject) => {
    const query = getQuery(event);
    const path = query.path;
    fs.readFile(`${path}`, "utf-8", (err, data) => {
      if (err) {
        reject(err);
      }
      resolve(data);
    });
  });
});

export { readblog as default };
//# sourceMappingURL=readblog.mjs.map
