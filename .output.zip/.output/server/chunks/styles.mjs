const interopDefault = r => r.default || r || [];
const styles = {
  "pages/blogs/[blogPath].vue": () => import('./_blogPath_-styles.c8e724a8.mjs').then(interopDefault),
  "pages/game/breakout.vue": () => import('./breakout-styles.c246eb01.mjs').then(interopDefault),
  "pages/game/kingandpigs.vue": () => import('./kingandpigs-styles.fb201ac3.mjs').then(interopDefault),
  "pages/game/knifehit.vue": () => import('./knifehit-styles.03943279.mjs').then(interopDefault),
  "pages/three/box.vue": () => import('./box-styles.50b588ca.mjs').then(interopDefault),
  "pages/three/vrhouse.vue": () => import('./vrhouse-styles.416313f3.mjs').then(interopDefault),
  "pages/three/bear.vue": () => import('./bear-styles.029a06ca.mjs').then(interopDefault),
  "components/BlogsTree.vue": () => import('./BlogsTree-styles.c2063a30.mjs').then(interopDefault),
  "components/BlogShow.vue": () => import('./BlogShow-styles.f344623c.mjs').then(interopDefault),
  "app.vue": () => import('./app-styles.27bb6d44.mjs').then(interopDefault),
  "error.vue": () => import('./error-styles.8dce8c52.mjs').then(interopDefault),
  "components/navigation.vue": () => import('./navigation-styles.a45d9eb4.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
