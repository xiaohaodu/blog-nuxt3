const knifehit_vue_vue_type_style_index_0_scoped_f3ff41aa_lang = "#knifehit[data-v-f3ff41aa]{height:100vh;overflow:hidden;text-align:center;width:100vw}";

const knifehitStyles_03943279 = [knifehit_vue_vue_type_style_index_0_scoped_f3ff41aa_lang];

export { knifehitStyles_03943279 as default };
//# sourceMappingURL=knifehit-styles.03943279.mjs.map
