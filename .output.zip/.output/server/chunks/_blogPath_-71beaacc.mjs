import { defineComponent, computed, openBlock, createElementBlock, mergeProps, unref, renderSlot, useSSRContext, withAsyncContext, ref, provide, resolveComponent, withCtx, createTextVNode, toDisplayString, createVNode, withDirectives, vShow, inject } from 'vue';
import { b as buildProps, d as definePropType, u as useNamespace, i as isUndefined, a as addUnit, _ as _export_sfc$1, f as useRouter, g as useNuxtApp, e as useHead } from './server.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-5d0b373b.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderStyle, ssrRenderList, ssrRenderAttrs } from 'vue/server-renderer';
import { marked } from 'marked';
import hljs from 'highlight.js';
import DOMPurify from 'isomorphic-dompurify';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import '@vue/shared';
import 'lodash-unified';
import '@vueuse/core';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'defu';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const withInstall = (main, extra) => {
  main.install = (app) => {
    for (const comp of [main, ...Object.values(extra != null ? extra : {})]) {
      app.component(comp.name, comp);
    }
  };
  if (extra) {
    for (const [key, comp] of Object.entries(extra)) {
      main[key] = comp;
    }
  }
  return main;
};
var _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const iconProps = buildProps({
  size: {
    type: definePropType([Number, String])
  },
  color: {
    type: String
  }
});
const __default__ = /* @__PURE__ */ defineComponent({
  name: "ElIcon",
  inheritAttrs: false
});
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  ...__default__,
  props: iconProps,
  setup(__props) {
    const props = __props;
    const ns = useNamespace("icon");
    const style = computed(() => {
      const { size, color } = props;
      if (!size && !color)
        return {};
      return {
        fontSize: isUndefined(size) ? void 0 : addUnit(size),
        "--color": color
      };
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("i", mergeProps({
        class: unref(ns).b(),
        style: unref(style)
      }, _ctx.$attrs), [
        renderSlot(_ctx.$slots, "default")
      ], 16);
    };
  }
});
var Icon = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/icon/src/icon.vue"]]);
const ElIcon = withInstall(Icon);
const removeUndefinedProps = (props) => Object.fromEntries(Object.entries(props).filter(([, value]) => value !== void 0));
const setupForUseMeta = (metaFactory, renderChild) => (props, ctx) => {
  useHead(() => metaFactory({ ...removeUndefinedProps(props), ...ctx.attrs }, ctx));
  return () => {
    var _a, _b;
    return renderChild ? (_b = (_a = ctx.slots).default) == null ? void 0 : _b.call(_a) : null;
  };
};
const globalProps = {
  accesskey: String,
  autocapitalize: String,
  autofocus: {
    type: Boolean,
    default: void 0
  },
  class: [String, Object, Array],
  contenteditable: {
    type: Boolean,
    default: void 0
  },
  contextmenu: String,
  dir: String,
  draggable: {
    type: Boolean,
    default: void 0
  },
  enterkeyhint: String,
  exportparts: String,
  hidden: {
    type: Boolean,
    default: void 0
  },
  id: String,
  inputmode: String,
  is: String,
  itemid: String,
  itemprop: String,
  itemref: String,
  itemscope: String,
  itemtype: String,
  lang: String,
  nonce: String,
  part: String,
  slot: String,
  spellcheck: {
    type: Boolean,
    default: void 0
  },
  style: String,
  tabindex: String,
  title: String,
  translate: String
};
const Title = /* @__PURE__ */ defineComponent({
  // eslint-disable-next-line vue/no-reserved-component-names
  name: "Title",
  inheritAttrs: false,
  setup: setupForUseMeta((_, { slots }) => {
    var _a, _b, _c;
    const title = ((_c = (_b = (_a = slots.default) == null ? void 0 : _a.call(slots)) == null ? void 0 : _b[0]) == null ? void 0 : _c.children) || null;
    return {
      title
    };
  })
});
const Meta = /* @__PURE__ */ defineComponent({
  // eslint-disable-next-line vue/no-reserved-component-names
  name: "Meta",
  inheritAttrs: false,
  props: {
    ...globalProps,
    charset: String,
    content: String,
    httpEquiv: String,
    name: String,
    body: Boolean,
    renderPriority: [String, Number]
  },
  setup: setupForUseMeta((props) => {
    const meta = { ...props };
    if (meta.httpEquiv) {
      meta["http-equiv"] = meta.httpEquiv;
      delete meta.httpEquiv;
    }
    return {
      meta: [meta]
    };
  })
});
const Head = /* @__PURE__ */ defineComponent({
  // eslint-disable-next-line vue/no-reserved-component-names
  name: "Head",
  inheritAttrs: false,
  setup: (_props, ctx) => () => {
    var _a, _b;
    return (_b = (_a = ctx.slots).default) == null ? void 0 : _b.call(_a);
  }
});
const _sfc_main$2 = {
  __name: "BlogsTree",
  __ssrInlineRender: true,
  props: ["blogsTree", "active"],
  setup(__props) {
    const props = __props;
    const blogsTree = props.blogsTree;
    const setBlogPath = inject("setBlogPath");
    const fileNameHandler = (item) => {
      return item.name.replace(/(.md|.js)$/, "");
    };
    const fileBlogPathHandler = (item) => {
      return item.path.slice(14, -3);
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0;
      const _component_BlogsTree = __nuxt_component_4;
      _push(`<!--[-->`);
      ssrRenderList(unref(blogsTree), (item, index) => {
        _push(`<li data-v-23e9bcd6>`);
        if (item.type == "file") {
          _push(ssrRenderComponent(_component_nuxt_link, {
            to: `/blogs/${fileBlogPathHandler(item)}`,
            onClick: ($event) => unref(setBlogPath)(item.path),
            class: [{ active: fileBlogPathHandler(item) == props.active }, "file"]
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(fileNameHandler(item))}`);
              } else {
                return [
                  createTextVNode(toDisplayString(fileNameHandler(item)), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        if (item.type == "dir") {
          _push(`<span data-v-23e9bcd6>${ssrInterpolate(item.name)}</span>`);
        } else {
          _push(`<!---->`);
        }
        if (item.type == "dir" && item.children.length) {
          _push(`<ul data-v-23e9bcd6>`);
          if (item.type == "dir" && item.children.length) {
            _push(ssrRenderComponent(_component_BlogsTree, {
              blogsTree: item.children,
              active: props.active
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</ul>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</li>`);
      });
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/BlogsTree.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc$1(_sfc_main$2, [["__scopeId", "data-v-23e9bcd6"]]);
const _sfc_main$1 = {
  __name: "BlogShow",
  __ssrInlineRender: true,
  props: ["blogContent"],
  setup(__props) {
    const props = __props;
    const blogContent = computed(() => {
      return DOMPurify.sanitize(marked.parse(props.blogContent.replace(/^[\u200B\u200C\u200D\u200E\u200F\uFEFF]/, "")));
    });
    marked.setOptions({
      renderer: new marked.Renderer(),
      highlight: function(code, lang) {
        const language = hljs.getLanguage(lang) ? lang : "plaintext";
        return hljs.highlight(code, { language }).value;
      },
      langPrefix: "hljs language-",
      // highlight.js css expects a top-level 'hljs' class.
      async: false,
      breaks: false,
      gfm: true,
      headerIds: true,
      headerPrefix: "",
      mangle: true,
      pedantic: false,
      sanitize: false,
      silent: false,
      smartypants: false,
      xhtml: false
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ id: "blogContent" }, _attrs))} data-v-b7d513c4>${unref(blogContent)}</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/BlogShow.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc$1(_sfc_main$1, [["__scopeId", "data-v-b7d513c4"]]);
const _sfc_main = {
  __name: "[blogPath]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const router = useRouter();
    const blogsTree = ([__temp, __restore] = withAsyncContext(() => $fetch("/api/blogsTree")), __temp = await __temp, __restore(), __temp);
    const initContent = ([__temp, __restore] = withAsyncContext(() => $fetch("/api/readblog", {
      params: { path: `public/_${decodeURIComponent(router.currentRoute.value.fullPath.substring(1))}.md` }
    })), __temp = await __temp, __restore(), __temp);
    let blogContent = ref(initContent);
    let blogPath = ref("");
    const active = computed(() => {
      return typeof router.currentRoute.value.params.blogPath == "string" ? router.currentRoute.value.params.blogPath : router.currentRoute.value.params.blogPath.join("/");
    });
    const setBlogPath = async (content) => {
      blogPath.value = content;
      blogContent.value = await $fetch("/api/readblog", { params: { path: blogPath.value } });
    };
    provide("setBlogPath", setBlogPath);
    useNuxtApp();
    const show = ref(false);
    const showTag = () => {
      show.value = !show.value;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_Meta = Meta;
      const _component_el_icon = ElIcon;
      const _component_Expand = resolveComponent("Expand");
      const _component_Fold = resolveComponent("Fold");
      const _component_BlogsTree = __nuxt_component_4;
      const _component_BlogShow = __nuxt_component_5;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(router).currentRoute.value.params.blogName)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(router).currentRoute.value.params.blogName), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "referrer",
              content: "no-referrer"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "content",
              content: unref(blogContent)
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(router).currentRoute.value.params.blogName), 1)
                ]),
                _: 1
              }),
              createVNode(_component_Meta, {
                name: "referrer",
                content: "no-referrer"
              }),
              createVNode(_component_Meta, {
                name: "content",
                content: unref(blogContent)
              }, null, 8, ["content"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div id="blogs" data-v-f89d2726>`);
      _push(ssrRenderComponent(_component_el_icon, { onClick: showTag }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Expand, {
              style: !unref(show) ? null : { display: "none" }
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Fold, {
              style: unref(show) ? null : { display: "none" }
            }, null, _parent2, _scopeId));
          } else {
            return [
              withDirectives(createVNode(_component_Expand, null, null, 512), [
                [vShow, !unref(show)]
              ]),
              withDirectives(createVNode(_component_Fold, null, null, 512), [
                [vShow, unref(show)]
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<aside id="blogsTreeTag" style="${ssrRenderStyle(unref(show) ? null : { display: "none" })}" data-v-f89d2726><ul data-v-f89d2726>`);
      _push(ssrRenderComponent(_component_BlogsTree, {
        blogsTree: unref(blogsTree),
        active: unref(active)
      }, null, _parent));
      _push(`</ul></aside><aside id="blogsTree" data-v-f89d2726><ul data-v-f89d2726>`);
      _push(ssrRenderComponent(_component_BlogsTree, {
        blogsTree: unref(blogsTree),
        active: unref(active)
      }, null, _parent));
      _push(`</ul></aside><div id="blogShow" data-v-f89d2726>`);
      _push(ssrRenderComponent(_component_BlogShow, { blogContent: unref(blogContent) }, null, _parent));
      _push(`</div></div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/blogs/[blogPath].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _blogPath_ = /* @__PURE__ */ _export_sfc$1(_sfc_main, [["__scopeId", "data-v-f89d2726"]]);

export { _blogPath_ as default };
//# sourceMappingURL=_blogPath_-71beaacc.mjs.map
