const BlogsTree_vue_vue_type_style_index_0_scoped_23e9bcd6_lang = ".file[data-v-23e9bcd6]{cursor:pointer}[theme=light] .file[data-v-23e9bcd6]:hover,[theme=night] .file[data-v-23e9bcd6]:hover{color:#5bac87;transition:color .25s}[theme=light] .active[data-v-23e9bcd6],[theme=night] .active[data-v-23e9bcd6]{color:#42b883;font-weight:600;transition:color .25s,font-weight .25s}a[data-v-23e9bcd6]{text-decoration:none;word-break:break-all}";

const BlogsTreeStyles_c2063a30 = [BlogsTree_vue_vue_type_style_index_0_scoped_23e9bcd6_lang];

export { BlogsTreeStyles_c2063a30 as default };
//# sourceMappingURL=BlogsTree-styles.c2063a30.mjs.map
