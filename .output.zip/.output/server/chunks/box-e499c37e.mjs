import { ref, mergeProps, useSSRContext } from 'vue';
import { _ as _export_sfc, g as useNuxtApp } from './server.mjs';
import { ssrRenderAttrs } from 'vue/server-renderer';
import { S as Scene, P as PerspectiveCamera, W as WebGLRenderer, B as BoxGeometry, M as MeshBasicMaterial, a as Mesh } from './three.module-5a173086.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import '@vue/shared';
import 'lodash-unified';
import '@vueuse/core';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'defu';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {
  __name: "box",
  __ssrInlineRender: true,
  setup(__props) {
    const container = ref(null);
    const scene = new Scene();
    const camera = new PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1e3);
    camera.position.z = 5;
    const renderer = new WebGLRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    const geometry = new BoxGeometry(1, 1, 1);
    const material = new MeshBasicMaterial({ color: 65280 });
    const cube = new Mesh(geometry, material);
    scene.add(cube);
    useNuxtApp();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        ref_key: "container",
        ref: container,
        id: "container"
      }, _attrs))} data-v-3956f9ca></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/three/box.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const box = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-3956f9ca"]]);

export { box as default };
//# sourceMappingURL=box-e499c37e.mjs.map
