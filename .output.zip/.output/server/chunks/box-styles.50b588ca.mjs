const box_vue_vue_type_style_index_0_scoped_3956f9ca_lang = "#container[data-v-3956f9ca]{height:100vh;overflow:hidden;width:100vw}";

const boxStyles_50b588ca = [box_vue_vue_type_style_index_0_scoped_3956f9ca_lang];

export { boxStyles_50b588ca as default };
//# sourceMappingURL=box-styles.50b588ca.mjs.map
