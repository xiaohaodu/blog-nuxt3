const breakout_vue_vue_type_style_index_0_scoped_b791bb86_lang = "#breakout[data-v-b791bb86]{height:100vh;overflow:hidden;text-align:center;width:100vw}";

const breakoutStyles_c246eb01 = [breakout_vue_vue_type_style_index_0_scoped_b791bb86_lang];

export { breakoutStyles_c246eb01 as default };
//# sourceMappingURL=breakout-styles.c246eb01.mjs.map
