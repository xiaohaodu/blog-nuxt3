import { defineEventHandler } from 'h3';
import fs from 'fs';

function getfiles(path) {
  const dirfiles = fs.readdirSync(path, { encoding: "utf8", withFileTypes: true });
  return dirfiles;
}
function isFile(filepath) {
  let stat = fs.statSync(filepath);
  return stat.isFile();
}
function isDir(filepath) {
  let stat = fs.statSync(filepath);
  return stat.isDirectory();
}
function getAllfiles(path, arr) {
  const filesArr = getfiles(path);
  if (path.slice(-1) == "/") {
    path = path.slice(0, -1);
  }
  filesArr.forEach((item) => {
    const fileName = item.name;
    const filePath = `${path}/${fileName}`;
    if (isDir(filePath)) {
      const itemFileArr = [];
      getAllfiles(filePath, itemFileArr);
      const dir = { name: fileName, type: "dir", dirPath: `${filePath}/`, children: itemFileArr };
      arr.push(dir);
    } else if (isFile(filePath)) {
      arr.push({ name: fileName, type: "file", path: filePath });
    }
  });
}
const blogsTreeHandler = (blogsTree) => {
  let obj;
  for (const key in blogsTree) {
    if (blogsTree[key].name == "README.md") {
      obj = { ...blogsTree[key] };
      blogsTree.splice(key, 1);
      blogsTree.unshift(obj);
      return;
    }
  }
};

const blogsTree = defineEventHandler((even) => {
  return new Promise((resolve, reject) => {
    const blogsTree = [];
    try {
      getAllfiles("public/_blogs", blogsTree);
      blogsTreeHandler(blogsTree);
      resolve(blogsTree);
    } catch (error) {
      reject(error);
    }
  });
});

export { blogsTree as default };
//# sourceMappingURL=blogsTree.mjs.map
