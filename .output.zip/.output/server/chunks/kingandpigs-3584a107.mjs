import { b as buildAssetsURL } from './renderer.mjs';
import { ref, mergeProps, useSSRContext } from 'vue';
import { _ as _export_sfc, g as useNuxtApp } from './server.mjs';
import { ssrRenderAttrs } from 'vue/server-renderer';
import Phaser from 'phaser';
import 'vue-bundle-renderer/runtime';
import 'h3';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@vue/shared';
import 'lodash-unified';
import '@vueuse/core';

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
const compressionlevel = -1;
const editorsettings = {
  chunksize: {
    height: 32,
    width: 32
  }
};
const height = 10;
const infinite = false;
const layers = [
  {
    data: [
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      135,
      136,
      136,
      136,
      136,
      136,
      136,
      136,
      136,
      136,
      136,
      136,
      136,
      136,
      136,
      136,
      136,
      137,
      41,
      41,
      154,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      156,
      41,
      41,
      154,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      156,
      41,
      41,
      154,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      156,
      41,
      41,
      154,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      156,
      41,
      41,
      154,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      155,
      156,
      41,
      41,
      154,
      155,
      155,
      155,
      155,
      155,
      141,
      174,
      174,
      174,
      174,
      142,
      155,
      155,
      155,
      155,
      155,
      156,
      41,
      41,
      173,
      174,
      174,
      174,
      174,
      174,
      175,
      41,
      41,
      41,
      41,
      173,
      174,
      174,
      174,
      174,
      174,
      175,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      0,
      0,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41,
      41
    ],
    height: 10,
    id: 1,
    name: "bg",
    opacity: 1,
    type: "tilelayer",
    visible: true,
    width: 20,
    x: 0,
    y: 0
  },
  {
    data: [
      27,
      60,
      60,
      60,
      60,
      60,
      60,
      60,
      60,
      60,
      60,
      60,
      60,
      60,
      60,
      60,
      60,
      60,
      60,
      28,
      42,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      40,
      42,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      40,
      42,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      40,
      42,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      30,
      42,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      40,
      42,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      40,
      50,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      40,
      42,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      21,
      22,
      22,
      23,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      40,
      46,
      22,
      22,
      22,
      22,
      22,
      22,
      22,
      47,
      0,
      0,
      46,
      22,
      22,
      22,
      22,
      22,
      22,
      22,
      47
    ],
    height: 10,
    id: 2,
    name: "collider",
    opacity: 1,
    type: "tilelayer",
    visible: true,
    width: 20,
    x: 0,
    y: 0
  },
  {
    data: [
      27,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    height: 10,
    id: 4,
    name: "pigCollider",
    opacity: 1,
    type: "tilelayer",
    visible: true,
    width: 20,
    x: 0,
    y: 0
  },
  {
    draworder: "topdown",
    id: 3,
    name: "object",
    objects: [
      {
        height: 0,
        id: 21,
        name: "pig",
        point: true,
        rotation: 0,
        type: "",
        visible: true,
        width: 0,
        x: 414,
        y: 259
      },
      {
        height: 0,
        id: 23,
        name: "coin",
        point: true,
        rotation: 0,
        type: "",
        visible: true,
        width: 0,
        x: 309,
        y: 223
      },
      {
        height: 0,
        id: 24,
        name: "fromDoor",
        point: true,
        rotation: 0,
        type: "",
        visible: true,
        width: 0,
        x: 119,
        y: 255
      },
      {
        height: 0,
        id: 31,
        name: "king",
        point: true,
        rotation: 0,
        type: "",
        visible: true,
        width: 0,
        x: 117,
        y: 273
      },
      {
        height: 0,
        id: 32,
        name: "toDoor",
        point: true,
        rotation: 0,
        type: "",
        visible: true,
        width: 0,
        x: 558,
        y: 259
      }
    ],
    opacity: 1,
    type: "objectgroup",
    visible: true,
    x: 0,
    y: 0
  }
];
const nextlayerid = 5;
const nextobjectid = 33;
const orientation = "orthogonal";
const renderorder = "right-down";
const tiledversion = "1.10.1";
const tileheight = 32;
const tilesets = [
  {
    columns: 19,
    firstgid: 1,
    image: "Terrain(32x32).png",
    imageheight: 416,
    imagewidth: 608,
    margin: 0,
    name: "Terrain(32x32)",
    spacing: 0,
    tilecount: 247,
    tileheight: 32,
    tiles: [
      {
        id: 0,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 20,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 21,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 22,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 24,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 26,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 27,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 29,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 30,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 32,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 33,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 35,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 39,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 41,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 43,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 45,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 46,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 48,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 49,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 51,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            },
            {
              height: 32,
              id: 2,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 52,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 54,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 55,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 58,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 59,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 60,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 62,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 83,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 84,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 86,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 87,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 89,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 90,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            },
            {
              height: 32,
              id: 2,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 92,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 93,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 96,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 97,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 98,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 100,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 102,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 103,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 105,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 106,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 108,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 109,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 111,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      },
      {
        id: 112,
        objectgroup: {
          draworder: "index",
          id: 2,
          name: "",
          objects: [
            {
              height: 32,
              id: 1,
              name: "",
              rotation: 0,
              type: "",
              visible: true,
              width: 32,
              x: 0,
              y: 0
            }
          ],
          opacity: 1,
          type: "objectgroup",
          visible: true,
          x: 0,
          y: 0
        }
      }
    ],
    tilewidth: 32
  },
  {
    columns: 7,
    firstgid: 248,
    image: "Decorations(32x32).png",
    imageheight: 192,
    imagewidth: 224,
    margin: 0,
    name: "Decorations(32x32)",
    spacing: 0,
    tilecount: 42,
    tileheight: 32,
    tilewidth: 32
  }
];
const tilewidth = 32;
const type = "map";
const version = "1.10";
const width = 20;
const MapBegin = {
  compressionlevel,
  editorsettings,
  height,
  infinite,
  layers,
  nextlayerid,
  nextobjectid,
  orientation,
  renderorder,
  tiledversion,
  tileheight,
  tilesets,
  tilewidth,
  type,
  version,
  width
};
const Terrain = "" + buildAssetsURL("Terrain(32x32).5cda6d4e.png");
const kingSpritesheet = "" + buildAssetsURL("02-KingHuman.ed4978af.png");
const frames$7 = [
  {
    filename: "0",
    frame: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "1",
    frame: {
      x: 96,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "2",
    frame: {
      x: 192,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "3",
    frame: {
      x: 288,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "4",
    frame: {
      x: 384,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "5",
    frame: {
      x: 480,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "6",
    frame: {
      x: 576,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "7",
    frame: {
      x: 672,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "8",
    frame: {
      x: 768,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "9",
    frame: {
      x: 864,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "10",
    frame: {
      x: 960,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "11",
    frame: {
      x: 1056,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "12",
    frame: {
      x: 1152,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "13",
    frame: {
      x: 1248,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "14",
    frame: {
      x: 1344,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "15",
    frame: {
      x: 1440,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "16",
    frame: {
      x: 1536,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "17",
    frame: {
      x: 1632,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "18",
    frame: {
      x: 1728,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "19",
    frame: {
      x: 1824,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "20",
    frame: {
      x: 1920,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "21",
    frame: {
      x: 2016,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "22",
    frame: {
      x: 2112,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "23",
    frame: {
      x: 2208,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "24",
    frame: {
      x: 2304,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "25",
    frame: {
      x: 2400,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "26",
    frame: {
      x: 2496,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "27",
    frame: {
      x: 2592,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "28",
    frame: {
      x: 2688,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "29",
    frame: {
      x: 2784,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "30",
    frame: {
      x: 2880,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "31",
    frame: {
      x: 2976,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "32",
    frame: {
      x: 3072,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "33",
    frame: {
      x: 3168,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "34",
    frame: {
      x: 3264,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "35",
    frame: {
      x: 3360,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "36",
    frame: {
      x: 3456,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "37",
    frame: {
      x: 3552,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "38",
    frame: {
      x: 3648,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "39",
    frame: {
      x: 3744,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "40",
    frame: {
      x: 3840,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "41",
    frame: {
      x: 3936,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "42",
    frame: {
      x: 4032,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "43",
    frame: {
      x: 4128,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "44",
    frame: {
      x: 4224,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "45",
    frame: {
      x: 4320,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "46",
    frame: {
      x: 4416,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  }
];
const meta$7 = {
  app: "http://www.aseprite.org/",
  version: "1.2.27-dev",
  image: "02-KingHuman.png",
  format: "RGBA8888",
  size: {
    w: 4512,
    h: 96
  },
  scale: "1",
  frameTags: [
    {
      name: "kingIdle",
      from: 0,
      to: 10,
      direction: "forward"
    },
    {
      name: "kingJump",
      from: 11,
      to: 13,
      direction: "forward"
    },
    {
      name: "kingRun",
      from: 14,
      to: 21,
      direction: "forward"
    },
    {
      name: "kingAttack",
      from: 22,
      to: 24,
      direction: "forward"
    },
    {
      name: "kingHit",
      from: 25,
      to: 26,
      direction: "forward"
    },
    {
      name: "kingDead",
      from: 27,
      to: 30,
      direction: "forward"
    },
    {
      name: "kingDoorIn",
      from: 31,
      to: 38,
      direction: "forward"
    },
    {
      name: "kingDoorOut",
      from: 39,
      to: 46,
      direction: "forward"
    }
  ],
  layers: [
    {
      name: "Dibujo",
      opacity: 255,
      blendMode: "normal"
    }
  ],
  slices: []
};
const kingSpritesheetJson = {
  frames: frames$7,
  meta: meta$7
};
const pigSpritesheet = "" + buildAssetsURL("03-Pig.73ccdc30.png");
const frames$6 = [
  {
    filename: "0",
    frame: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "1",
    frame: {
      x: 80,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "2",
    frame: {
      x: 160,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "3",
    frame: {
      x: 240,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "4",
    frame: {
      x: 320,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "5",
    frame: {
      x: 400,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "6",
    frame: {
      x: 480,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "7",
    frame: {
      x: 560,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "8",
    frame: {
      x: 640,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "9",
    frame: {
      x: 720,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "10",
    frame: {
      x: 800,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "11",
    frame: {
      x: 880,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "12",
    frame: {
      x: 960,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "13",
    frame: {
      x: 1040,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "14",
    frame: {
      x: 1120,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "15",
    frame: {
      x: 1200,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "16",
    frame: {
      x: 1280,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "17",
    frame: {
      x: 1360,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "18",
    frame: {
      x: 1440,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "19",
    frame: {
      x: 1520,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "20",
    frame: {
      x: 1600,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "21",
    frame: {
      x: 1680,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "22",
    frame: {
      x: 1760,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "23",
    frame: {
      x: 1840,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "24",
    frame: {
      x: 1920,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "25",
    frame: {
      x: 2e3,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "26",
    frame: {
      x: 2080,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "27",
    frame: {
      x: 2160,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "28",
    frame: {
      x: 2240,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "29",
    frame: {
      x: 2320,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "30",
    frame: {
      x: 2400,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  }
];
const meta$6 = {
  app: "http://www.aseprite.org/",
  version: "1.2.27-dev",
  image: "03-Pig.png",
  format: "RGBA8888",
  size: {
    w: 2480,
    h: 80
  },
  scale: "1",
  frameTags: [
    {
      name: "pigIdle",
      from: 0,
      to: 10,
      direction: "forward"
    },
    {
      name: "pigRun",
      from: 11,
      to: 16,
      direction: "forward"
    },
    {
      name: "pigJump",
      from: 17,
      to: 19,
      direction: "forward"
    },
    {
      name: "pigAttack",
      from: 20,
      to: 24,
      direction: "forward"
    },
    {
      name: "pigHit",
      from: 25,
      to: 26,
      direction: "forward"
    },
    {
      name: "pigDead",
      from: 27,
      to: 30,
      direction: "forward"
    }
  ],
  layers: [
    {
      name: "Dibujo",
      opacity: 255,
      blendMode: "normal"
    }
  ],
  slices: []
};
const pigSpritesheetJson = {
  frames: frames$6,
  meta: meta$6
};
const pigBoxSpritesheet = "" + buildAssetsURL("04-PigBox.e6f2b402.png");
const frames$5 = [
  {
    filename: "0",
    frame: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "1",
    frame: {
      x: 80,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "2",
    frame: {
      x: 160,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "3",
    frame: {
      x: 240,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "4",
    frame: {
      x: 320,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "5",
    frame: {
      x: 400,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "6",
    frame: {
      x: 480,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "7",
    frame: {
      x: 560,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "8",
    frame: {
      x: 640,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "9",
    frame: {
      x: 720,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "10",
    frame: {
      x: 800,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "11",
    frame: {
      x: 880,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "12",
    frame: {
      x: 960,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "13",
    frame: {
      x: 1040,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "14",
    frame: {
      x: 1120,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "15",
    frame: {
      x: 1200,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "16",
    frame: {
      x: 1280,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "17",
    frame: {
      x: 1360,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "18",
    frame: {
      x: 1440,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "19",
    frame: {
      x: 1520,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "20",
    frame: {
      x: 1600,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "21",
    frame: {
      x: 1680,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "22",
    frame: {
      x: 1760,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "23",
    frame: {
      x: 1840,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "24",
    frame: {
      x: 1920,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  }
];
const meta$5 = {
  app: "http://www.aseprite.org/",
  version: "1.2.27-dev",
  image: "04-PigBox.png",
  format: "RGBA8888",
  size: {
    w: 2e3,
    h: 80
  },
  scale: "1",
  frameTags: [
    {
      name: "PickingBox",
      from: 0,
      to: 4,
      direction: "forward"
    },
    {
      name: "pigBoxIdle",
      from: 5,
      to: 13,
      direction: "forward"
    },
    {
      name: "pigBoxRun",
      from: 14,
      to: 19,
      direction: "forward"
    },
    {
      name: "ThrowingBox",
      from: 20,
      to: 24,
      direction: "forward"
    }
  ],
  layers: [
    {
      name: "Pig",
      opacity: 255,
      blendMode: "normal"
    }
  ],
  slices: []
};
const pigBoxSpritesheetJson = {
  frames: frames$5,
  meta: meta$5
};
const pigBoomSpritesheet = "" + buildAssetsURL("05-PigBoom.9b30afbb.png");
const frames$4 = [
  {
    filename: "0",
    frame: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "1",
    frame: {
      x: 80,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "2",
    frame: {
      x: 160,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "3",
    frame: {
      x: 240,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "4",
    frame: {
      x: 320,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "5",
    frame: {
      x: 400,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "6",
    frame: {
      x: 480,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "7",
    frame: {
      x: 560,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "8",
    frame: {
      x: 640,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "9",
    frame: {
      x: 720,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "10",
    frame: {
      x: 800,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "11",
    frame: {
      x: 880,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "12",
    frame: {
      x: 960,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "13",
    frame: {
      x: 1040,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "14",
    frame: {
      x: 1120,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "15",
    frame: {
      x: 1200,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "16",
    frame: {
      x: 1280,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "17",
    frame: {
      x: 1360,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "18",
    frame: {
      x: 1440,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "19",
    frame: {
      x: 1520,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "20",
    frame: {
      x: 1600,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "21",
    frame: {
      x: 1680,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "22",
    frame: {
      x: 1760,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "23",
    frame: {
      x: 1840,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "24",
    frame: {
      x: 1920,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  }
];
const meta$4 = {
  app: "http://www.aseprite.org/",
  version: "1.2.27-dev",
  image: "05-PigBoom.png",
  format: "RGBA8888",
  size: {
    w: 2e3,
    h: 80
  },
  scale: "1",
  frameTags: [
    {
      name: "PickingBomb",
      from: 0,
      to: 3,
      direction: "forward"
    },
    {
      name: "pigBoomIdle",
      from: 4,
      to: 13,
      direction: "forward"
    },
    {
      name: "pigBoomRun",
      from: 14,
      to: 19,
      direction: "forward"
    },
    {
      name: "ThrowingBoom",
      from: 20,
      to: 24,
      direction: "forward"
    }
  ],
  layers: [
    {
      name: "Pig",
      opacity: 255,
      blendMode: "normal"
    }
  ],
  slices: []
};
const pigBoomSpritesheetJson = {
  frames: frames$4,
  meta: meta$4
};
const pigHideSpritesheet = "" + buildAssetsURL("06-PigHide.57a37b2d.png");
const frames$3 = [
  {
    filename: "0",
    frame: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "1",
    frame: {
      x: 80,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "2",
    frame: {
      x: 160,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "3",
    frame: {
      x: 240,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "4",
    frame: {
      x: 320,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "5",
    frame: {
      x: 400,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "6",
    frame: {
      x: 480,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "7",
    frame: {
      x: 560,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "8",
    frame: {
      x: 640,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  }
];
const meta$3 = {
  app: "http://www.aseprite.org/",
  version: "1.2.27-dev",
  image: "06-PigHide.png",
  format: "RGBA8888",
  size: {
    w: 720,
    h: 80
  },
  scale: "1",
  frameTags: [
    {
      name: "Looking out",
      from: 0,
      to: 2,
      direction: "forward"
    },
    {
      name: "Jump",
      from: 3,
      to: 8,
      direction: "forward"
    },
    {
      name: "Anticipation",
      from: 3,
      to: 4,
      direction: "forward"
    },
    {
      name: "Jumps",
      from: 5,
      to: 6,
      direction: "forward"
    },
    {
      name: "Fall",
      from: 7,
      to: 7,
      direction: "forward"
    },
    {
      name: "Ground",
      from: 8,
      to: 8,
      direction: "forward"
    }
  ],
  layers: [
    {
      name: "Dibujo",
      opacity: 255,
      blendMode: "normal"
    }
  ],
  slices: []
};
const pigHideSpritesheetJson = {
  frames: frames$3,
  meta: meta$3
};
const kingPigSpritesheet = "" + buildAssetsURL("07-KingPig.7d054137.png");
const frames$2 = [
  {
    filename: "0",
    frame: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "1",
    frame: {
      x: 80,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "2",
    frame: {
      x: 160,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "3",
    frame: {
      x: 240,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "4",
    frame: {
      x: 320,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "5",
    frame: {
      x: 400,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "6",
    frame: {
      x: 480,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "7",
    frame: {
      x: 560,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "8",
    frame: {
      x: 640,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "9",
    frame: {
      x: 720,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "10",
    frame: {
      x: 800,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "11",
    frame: {
      x: 880,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "12",
    frame: {
      x: 960,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "13",
    frame: {
      x: 1040,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "14",
    frame: {
      x: 1120,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "15",
    frame: {
      x: 1200,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "16",
    frame: {
      x: 1280,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "17",
    frame: {
      x: 1360,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "18",
    frame: {
      x: 1440,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "19",
    frame: {
      x: 1520,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "20",
    frame: {
      x: 1600,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "21",
    frame: {
      x: 1680,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "22",
    frame: {
      x: 1760,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "23",
    frame: {
      x: 1840,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "24",
    frame: {
      x: 1920,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "25",
    frame: {
      x: 2e3,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "26",
    frame: {
      x: 2080,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "27",
    frame: {
      x: 2160,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "28",
    frame: {
      x: 2240,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "29",
    frame: {
      x: 2320,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "30",
    frame: {
      x: 2400,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  },
  {
    filename: "31",
    frame: {
      x: 2480,
      y: 0,
      w: 80,
      h: 80
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 80,
      h: 80
    },
    sourceSize: {
      w: 80,
      h: 80
    },
    duration: 100
  }
];
const meta$2 = {
  app: "http://www.aseprite.org/",
  version: "1.2.27-dev",
  image: "07-KingPig.png",
  format: "RGBA8888",
  size: {
    w: 2560,
    h: 80
  },
  scale: "1",
  frameTags: [
    {
      name: "pigKingIdle",
      from: 0,
      to: 11,
      direction: "forward"
    },
    {
      name: "pigKingRun",
      from: 12,
      to: 17,
      direction: "forward"
    },
    {
      name: "pigKingJump",
      from: 18,
      to: 20,
      direction: "forward"
    },
    {
      name: "pigKingAttack",
      from: 21,
      to: 25,
      direction: "forward"
    },
    {
      name: "pigKingHit",
      from: 26,
      to: 27,
      direction: "forward"
    },
    {
      name: "pigKingDead",
      from: 28,
      to: 31,
      direction: "forward"
    }
  ],
  layers: [
    {
      name: "Dibujo",
      opacity: 255,
      blendMode: "normal"
    }
  ],
  slices: []
};
const kingPigSpritesheetJson = {
  frames: frames$2,
  meta: meta$2
};
const doorsheet = "" + buildAssetsURL("11-Door.a4369bda.png");
const frames$1 = [
  {
    filename: "0",
    frame: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "1",
    frame: {
      x: 96,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "2",
    frame: {
      x: 192,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "3",
    frame: {
      x: 288,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "4",
    frame: {
      x: 384,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "5",
    frame: {
      x: 480,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "6",
    frame: {
      x: 576,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "7",
    frame: {
      x: 672,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "8",
    frame: {
      x: 768,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  }
];
const meta$1 = {
  app: "http://www.aseprite.org/",
  version: "1.2.27-dev",
  image: "11-Door.png",
  format: "RGBA8888",
  size: {
    w: 864,
    h: 96
  },
  scale: "1",
  frameTags: [
    {
      name: "doorIdle",
      from: 0,
      to: 0,
      direction: "forward"
    },
    {
      name: "doorOpening",
      from: 1,
      to: 5,
      direction: "forward"
    },
    {
      name: "doorClosing",
      from: 6,
      to: 8,
      direction: "forward"
    }
  ],
  layers: [
    {
      name: "Door",
      opacity: 255,
      blendMode: "normal"
    }
  ],
  slices: []
};
const doorsheetJson = {
  frames: frames$1,
  meta: meta$1
};
const livesAndCoinsSheet = "" + buildAssetsURL("12-Lives and Coins.f1f4bf3e.png");
const frames = [
  {
    filename: "0",
    frame: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "1",
    frame: {
      x: 96,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "2",
    frame: {
      x: 192,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "3",
    frame: {
      x: 288,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "4",
    frame: {
      x: 384,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "5",
    frame: {
      x: 480,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "6",
    frame: {
      x: 576,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "7",
    frame: {
      x: 672,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "8",
    frame: {
      x: 768,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "9",
    frame: {
      x: 864,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "10",
    frame: {
      x: 960,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "11",
    frame: {
      x: 1056,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "12",
    frame: {
      x: 1152,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "13",
    frame: {
      x: 1248,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "14",
    frame: {
      x: 1344,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "15",
    frame: {
      x: 1440,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "16",
    frame: {
      x: 1536,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "17",
    frame: {
      x: 1632,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "18",
    frame: {
      x: 1728,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "19",
    frame: {
      x: 1824,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "20",
    frame: {
      x: 1920,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "21",
    frame: {
      x: 2016,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "22",
    frame: {
      x: 2112,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "23",
    frame: {
      x: 2208,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "24",
    frame: {
      x: 2304,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "25",
    frame: {
      x: 2400,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "26",
    frame: {
      x: 2496,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "27",
    frame: {
      x: 2592,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "28",
    frame: {
      x: 2688,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "29",
    frame: {
      x: 2784,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "30",
    frame: {
      x: 2880,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "31",
    frame: {
      x: 2976,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "32",
    frame: {
      x: 3072,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "33",
    frame: {
      x: 3168,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "34",
    frame: {
      x: 3264,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "35",
    frame: {
      x: 3360,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "36",
    frame: {
      x: 3456,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "37",
    frame: {
      x: 3552,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "38",
    frame: {
      x: 3648,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "39",
    frame: {
      x: 3744,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "40",
    frame: {
      x: 3840,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  },
  {
    filename: "41",
    frame: {
      x: 3936,
      y: 0,
      w: 96,
      h: 96
    },
    rotated: false,
    trimmed: false,
    spriteSourceSize: {
      x: 0,
      y: 0,
      w: 96,
      h: 96
    },
    sourceSize: {
      w: 96,
      h: 96
    },
    duration: 100
  }
];
const meta = {
  app: "http://www.aseprite.org/",
  version: "1.2.27-dev",
  image: "12-Lives and Coins.png",
  format: "RGBA8888",
  size: {
    w: 4032,
    h: 96
  },
  scale: "1",
  frameTags: [
    {
      name: "Live Bar",
      from: 0,
      to: 0,
      direction: "forward"
    },
    {
      name: "smallHeartIdle",
      from: 1,
      to: 8,
      direction: "forward"
    },
    {
      name: "smallHeartHit",
      from: 9,
      to: 10,
      direction: "forward"
    },
    {
      name: "bigHeartIdle",
      from: 11,
      to: 18,
      direction: "forward"
    },
    {
      name: "bigHeartCollected",
      from: 19,
      to: 20,
      direction: "forward"
    },
    {
      name: "smallDiamondIdle",
      from: 21,
      to: 28,
      direction: "forward"
    },
    {
      name: "bigDiamondIdle",
      from: 29,
      to: 38,
      direction: "forward"
    },
    {
      name: "bigDiamondCollected",
      from: 39,
      to: 40,
      direction: "forward"
    },
    {
      name: "Numbers",
      from: 41,
      to: 41,
      direction: "forward"
    }
  ],
  layers: [
    {
      name: "Cannon",
      opacity: 255,
      blendMode: "normal"
    }
  ],
  slices: []
};
const livesAndCoinsSheetJson = {
  frames,
  meta
};
class BootScene extends Phaser.Scene {
  constructor() {
    super("BootScene");
  }
  preload() {
    this.load.on("progress", (value) => {
      console.log(value);
    });
    this.load.on("complete", () => {
      this.scene.start("GameStart");
    });
    this.load.image("Terrain", Terrain);
    this.load.tilemapTiledJSON("MapBegin", MapBegin);
    this.load.aseprite("kingsheet", kingSpritesheet, kingSpritesheetJson);
    this.load.aseprite("pigsheet", pigSpritesheet, pigSpritesheetJson);
    this.load.aseprite("livesAndCoinsSheet", livesAndCoinsSheet, livesAndCoinsSheetJson);
    this.load.aseprite("doorsheet", doorsheet, doorsheetJson);
    this.load.aseprite("pigboxsheet", pigBoxSpritesheet, pigBoxSpritesheetJson);
    this.load.aseprite("pigboomsheet", pigBoomSpritesheet, pigBoomSpritesheetJson);
    this.load.aseprite("pighidesheet", pigHideSpritesheet, pigHideSpritesheetJson);
    this.load.aseprite("pigkingsheet", kingPigSpritesheet, kingPigSpritesheetJson);
  }
  create() {
    this.anims.createFromAseprite("kingsheet");
    this.anims.createFromAseprite("pigsheet");
    this.anims.createFromAseprite("livesAndCoinsSheet");
    this.anims.createFromAseprite("doorsheet");
    this.anims.createFromAseprite("pigboxsheet");
    this.anims.createFromAseprite("pigboomsheet");
    this.anims.createFromAseprite("pighidesheet");
    this.anims.createFromAseprite("pigkingsheet");
  }
}
class King extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x = 0, y = 0, texture = "kingsheet", frame = 0) {
    var _a, _b;
    super(scene, x, y, texture, frame);
    __publicField(this, "cursors");
    __publicField(this, "cursorswasd");
    __publicField(this, "speed", 150);
    __publicField(this, "isAttack", false);
    __publicField(this, "rangeAttack");
    __publicField(this, "isDead", false);
    __publicField(this, "isActive", false);
    scene.add.existing(this);
    scene.physics.add.existing(this);
    this.setSize(20, 30);
    this.cursors = (_a = scene.input.keyboard) == null ? void 0 : _a.createCursorKeys();
    this.cursorswasd = { ...(_b = scene.input.keyboard) == null ? void 0 : _b.addKeys("W,S,A,D") };
    this.on("animationcomplete", (animation) => {
      if (animation.key == "kingAttack") {
        this.isAttack = false;
        this.isActive = false;
      }
      if (animation.key == "kingDoorOut" || animation.key == "kingDoorIn") {
        this.isActive = false;
        this.isAttack = false;
      }
    });
    this.rangeAttack = scene.add.zone(this.x + 32, this.y, 16, 16);
    scene.physics.add.existing(this.rangeAttack);
    this.rangeAttack.body.setAllowGravity(false);
  }
  outDoor() {
    this.anims.play({
      key: "kingDoorOut",
      repeat: 0
    }, true);
  }
  inDoor() {
    this.isActive = true;
    this.anims.play({
      key: "kingDoorIn",
      repeat: 0
    }, true);
  }
  getRangeAttack() {
    return this.rangeAttack;
  }
  getIsAttack() {
    return this.isAttack;
  }
  getIsDead() {
    return this.isDead;
  }
  update() {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
    this.setVelocityX(0);
    if (!this.isDead && !this.isActive && !this.isAttack) {
      if (this.flipX) {
        this.rangeAttack.x = this.x - 32;
        this.rangeAttack.y = this.y;
      } else {
        this.rangeAttack.x = this.x + 32;
        this.rangeAttack.y = this.y;
      }
      if (((_a = this.cursors) == null ? void 0 : _a.left.isDown) || ((_c = (_b = this.cursorswasd) == null ? void 0 : _b.A) == null ? void 0 : _c.isDown)) {
        this.setFlipX(true);
        this.setVelocityX(-this.speed);
        this.run();
      } else if (((_d = this.cursors) == null ? void 0 : _d.right.isDown) || ((_f = (_e = this.cursorswasd) == null ? void 0 : _e.D) == null ? void 0 : _f.isDown)) {
        this.setFlipX(false);
        this.setVelocityX(this.speed);
        this.run();
      } else {
        this.idle();
      }
      if ((((_g = this.cursors) == null ? void 0 : _g.up.isDown) || ((_i = (_h = this.cursorswasd) == null ? void 0 : _h.W) == null ? void 0 : _i.isDown)) && this.body.onFloor()) {
        this.setVelocityY(-this.speed);
      } else if (((_j = this.cursors) == null ? void 0 : _j.down.isDown) || ((_l = (_k = this.cursorswasd) == null ? void 0 : _k.S) == null ? void 0 : _l.isDown)) {
        this.setVelocityY(this.speed);
      }
      this.jump();
      this.attack();
    }
  }
  idle() {
    this.anims.play({ key: "kingIdle", repeat: -1 }, true);
  }
  run() {
    this.anims.play({ key: "kingRun", repeat: -1 }, true);
  }
  jump() {
    if (this.body.velocity.y < 0) {
      this.setTexture("kingsheet", 11);
    }
    if (this.body.velocity.y > 0) {
      this.setTexture("kingsheet", 12);
    }
  }
  dead() {
    if (!this.isDead) {
      this.isDead = true;
      this.anims.play({
        key: "kingDead",
        repeat: 0
      });
    }
  }
  attack() {
    var _a;
    if (((_a = this.cursors) == null ? void 0 : _a.space.isDown) && this.body.onFloor()) {
      this.isAttack = true;
      this.anims.play({
        key: "kingAttack",
        repeat: 0
      }, true);
    }
  }
}
const _Pig = class extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x, y, texture = "pigsheet", frame = 0) {
    var _a, _b;
    super(scene, x, y, texture, frame);
    __publicField(this, "cursors");
    __publicField(this, "cursorswasd");
    __publicField(this, "speed", 70);
    __publicField(this, "isDead", false);
    __publicField(this, "typeTexture", {
      type: "pig",
      key: "pigsheet",
      frame: 0,
      height: 18,
      width: 18,
      offsetx: 31,
      offsety: 23
    });
    scene.add.existing(this);
    scene.physics.add.existing(this);
    this.setSize(18, 18);
    this.cursors = (_a = scene.input.keyboard) == null ? void 0 : _a.createCursorKeys();
    this.cursorswasd = { ...(_b = scene.input.keyboard) == null ? void 0 : _b.addKeys("W,S,A,D") };
    this.on("animationcomplete", (animation) => {
    });
  }
  setType(type2) {
    this.typeTexture = { ..._Pig.typeTexture[type2] };
    this.setTexture(this.typeTexture.key, this.typeTexture.frame);
    this.setSize(this.typeTexture.width, this.typeTexture.height);
    this.setOffset(this.typeTexture.offsetx, this.typeTexture.offsety);
  }
  update() {
    var _a, _b;
    if (!this.isDead) {
      this.run();
      if (((_a = this.body) == null ? void 0 : _a.blocked.left) || ((_b = this.body) == null ? void 0 : _b.blocked.right)) {
        this.speed = -this.speed;
      }
      if (this.speed > 0) {
        this.setFlipX(true);
      } else {
        this.setFlipX(false);
      }
      this.setVelocityX(this.speed);
    } else {
      this.setVelocity(0);
    }
  }
  idle() {
    this.anims.play({
      key: `${this.typeTexture.type}Idle`,
      repeat: -1
    }, true);
  }
  run() {
    this.anims.play({
      key: `${this.typeTexture.type}Run`,
      repeat: -1
    }, true);
  }
  getIsDead() {
    return this.isDead;
  }
  dead() {
    if (!this.isDead) {
      this.isDead = true;
      this.anims.play({
        key: `${this.typeTexture.type}Dead`,
        repeat: 0
      }, true);
    }
  }
};
let Pig = _Pig;
__publicField(Pig, "typeTexture", {
  pig: {
    type: "pig",
    key: "pigsheet",
    frame: 0,
    width: 18,
    height: 18,
    offsetx: 31,
    offsety: 31
  },
  pigKing: {
    type: "pigKing",
    key: "pigkingsheet",
    frame: 0,
    width: 18,
    height: 20,
    offsetx: 31,
    offsety: 28
  },
  pigBox: {
    type: "pigBox",
    key: "pigboxsheet",
    frame: 5,
    width: 18,
    height: 26,
    offsetx: 31,
    offsety: 23
  },
  pigBoom: {
    type: "pigBoom",
    key: "pigboomsheet",
    frame: 4,
    width: 20,
    height: 18,
    offsetx: 31,
    offsety: 31
  }
});
class Coin extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, isBigDiamon = true, x = 0, y = 0, frame = 29, height2 = 12, width2 = 12, texture = "livesAndCoinsSheet") {
    super(scene, x, y, texture, frame);
    __publicField(this, "isDiamonHit", false);
    __publicField(this, "isBigDiamon", true);
    scene.add.existing(this);
    scene.physics.add.existing(this);
    this.body.setAllowGravity(false);
    this.setSize(width2, height2);
    this.isBigDiamon = isBigDiamon;
  }
  update() {
    if (!this.isDiamonHit) {
      this.anims.play({
        key: this.isBigDiamon ? "bigDiamondIdle" : "smallDiamondIdle",
        repeat: -1
      }, true);
    }
  }
  getIsDiamonHit() {
    return this.isDiamonHit;
  }
  diamondCollected() {
    if (!this.isDiamonHit) {
      this.isDiamonHit = true;
      this.anims.play({
        key: this.isBigDiamon ? "bigDiamondCollected" : "smallDiamondCollected",
        repeat: 0,
        hideOnComplete: true
      });
    }
  }
}
class Door extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x = 0, y = 0, texture = "doorsheet", frame = 0) {
    super(scene, x, y, texture, frame);
    scene.add.existing(this);
    scene.physics.add.existing(this);
    this.setSize(48, 56);
    this.body.setAllowGravity(false);
    this.setOffset(24, 25);
    this.on("animationcomplete", (animation) => {
      if (animation.key == "doorOpening")
        ;
    });
  }
  open() {
    this.anims.play({
      key: "doorOpening",
      repeat: 0
    }, true);
  }
  close() {
    this.anims.play({
      key: "doorClosing",
      repeat: 0
    }, true);
  }
}
class Live extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, isBigHeart = true, x = 0, y = 0, frame = 11, height2 = 10, width2 = 10, texture = "livesAndCoinsSheet") {
    super(scene, x, y, texture, frame);
    __publicField(this, "isHeartHit", false);
    __publicField(this, "isBigHeart", true);
    scene.add.existing(this);
    scene.physics.add.existing(this);
    this.body.setAllowGravity(false);
    this.setSize(width2, height2);
    this.isBigHeart = isBigHeart;
  }
  update() {
    if (!this.isHeartHit) {
      this.anims.play({
        key: this.isBigHeart ? "bigHeartIdle" : "smallHeartIdle",
        repeat: -1
      }, true);
    }
  }
  heartHit() {
    if (!this.isHeartHit) {
      this.isHeartHit = true;
      this.anims.play({
        key: this.isBigHeart ? "bigHeartHit" : "smallHeartHit",
        repeat: 0,
        hideOnComplete: true
      });
    }
  }
}
class GameManage extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x = 35, y = 18, texture = "livesAndCoinsSheet", frame = 0) {
    super(scene, x, y, texture, frame);
    __publicField(this, "lives", []);
    __publicField(this, "coins");
    scene.add.existing(this);
    scene.physics.add.existing(this);
    this.body.setAllowGravity(false);
    this.setSize(70, 35);
    this.lives.push(new Live(scene, false, this.x - 10, this.y, 1));
    this.lives.push(new Live(scene, false, this.x, this.y, 1));
    this.lives.push(new Live(scene, false, this.x + 10, this.y, 1));
    this.coins = {
      coin: new Coin(scene, false, this.x - 2, this.y + 13, 21, 12, 18),
      text: scene.add.text(this.x + 5, this.y + 5, "0", { fontFamily: "Arial", fontSize: 12, color: "#ffffff" }),
      num: 0
    };
  }
  update() {
    this.lives.forEach((live) => {
      live.update();
    });
    this.coins.coin.update();
  }
  death() {
    if (this.lives.length) {
      const live = this.lives.pop();
      live == null ? void 0 : live.heartHit();
    }
    return !Boolean(this.lives.length);
  }
  addCoins() {
    this.coins.num++;
    this.coins.text.setText(String(this.coins.num));
  }
}
class GameSceneBase extends Phaser.Scene {
  constructor(name) {
    super(name);
    __publicField(this, "king");
    __publicField(this, "initKingPosition", {
      x: 0,
      y: 0
    });
    __publicField(this, "pigs");
    __publicField(this, "coins");
    __publicField(this, "fromDoor");
    __publicField(this, "toDoor");
    __publicField(this, "gameManage");
    __publicField(this, "tipText");
    __publicField(this, "tilemap");
    __publicField(this, "tileset");
    __publicField(this, "colliderLayer");
    __publicField(this, "bgLayer");
  }
  createMapBase(tilemapKey, tilesetConfig, colliderLayerConfig, tilemapLayerName) {
    this.tilemap = this.make.tilemap({ key: tilemapKey });
    this.tileset = this.tilemap.addTilesetImage(tilesetConfig.tilesetName, tilesetConfig.key, tilesetConfig.tileWidth, tilesetConfig.tileHeight);
    this.bgLayer = this.tilemap.createLayer(tilemapLayerName, this.tileset);
    this.colliderLayer = this.tilemap.createLayer(colliderLayerConfig.layerID, this.tileset);
    this.colliderLayer.setCollisionFromCollisionGroup(true, false);
  }
  createDoorAndKing() {
    this.fromDoor = this.tilemap.createFromObjects("object", {
      name: "fromDoor",
      classType: Door,
      key: "doorsheet",
      frame: 0
    })[0];
    this.toDoor = this.tilemap.createFromObjects("object", {
      name: "toDoor",
      classType: Door,
      key: "doorsheet",
      frame: 0
    })[0];
    this.king = this.tilemap.createFromObjects("object", {
      name: "king",
      classType: King,
      key: "kingsheet",
      frame: 0
    })[0];
    this.initKingPosition.x = this.king.x;
    this.initKingPosition.y = this.king.y;
    this.physics.add.collider(this.king, this.colliderLayer);
    this.physics.add.overlap(this.king, this.toDoor, () => {
      var _a, _b, _c, _d;
      const pass = !((_a = this.pigs) == null ? void 0 : _a.filter((pig) => !pig.getIsDead()).length);
      if (((_c = (_b = this.king) == null ? void 0 : _b.cursors) == null ? void 0 : _c.space.isDown) && pass) {
        this.king.inDoor();
        (_d = this.toDoor) == null ? void 0 : _d.close();
      }
    });
    this.cameras.main.startFollow(this.king);
    this.king.outDoor();
    this.fromDoor.open();
  }
  createPig() {
    this.pigs = this.tilemap.createFromObjects("object", {
      name: "pig",
      classType: Pig
    });
    this.pigs.forEach((pig) => {
      pig.setType("pig");
    });
    this.physics.add.collider(this.pigs, this.colliderLayer);
    const pigColliderLayer = this.tilemap.createLayer("pigCollider", this.tileset);
    pigColliderLayer.setCollisionFromCollisionGroup(true, false);
    this.physics.add.collider(this.pigs, pigColliderLayer);
    if (this.king) {
      this.physics.add.overlap(this.king.getRangeAttack(), this.pigs, (rangeAttack, pig) => {
        var _a;
        const chackPig = pig;
        if ((_a = this.king) == null ? void 0 : _a.getIsAttack()) {
          chackPig.dead();
        }
      });
      this.physics.add.overlap(this.king, this.pigs, (king, pig) => {
        var _a, _b;
        const chackKing = king;
        const chackPig = pig;
        if (!chackPig.getIsDead()) {
          ((_a = this.gameManage) == null ? void 0 : _a.death()) ? chackKing.dead() : (_b = this.king) == null ? void 0 : _b.setPosition(this.initKingPosition.x, this.initKingPosition.y);
        }
      });
    }
  }
  createCoin() {
    this.coins = this.tilemap.createFromObjects("object", {
      name: "coin",
      classType: Coin,
      key: "livesAndCoinsSheet",
      frame: 29
    });
    this.physics.add.collider(this.coins, this.colliderLayer);
    if (this.king) {
      this.physics.add.overlap(this.king, this.coins, (king, coin) => {
        var _a, _b;
        const chackCoin = coin;
        chackCoin.diamondCollected();
        (_a = this.gameManage) == null ? void 0 : _a.addCoins();
        const index = this.coins.findIndex((ele) => ele === chackCoin);
        (_b = this.coins) == null ? void 0 : _b.splice(index, 1);
      });
    }
  }
  createManage() {
    this.gameManage = new GameManage(this);
  }
  createStart() {
    if (this.king) {
      this.tipText = this.add.text(35, 40, "w a s d / \u2191 \u2193 \u2190 \u2192  \u63A7\u5236king\u79FB\u52A8\nspace \u63A7\u5236\u56FD\u738B\u653B\u51FB\u548C\u8FDB\u5165\u4E0B\u4E00\u5173", { fontFamily: "Arial", fontSize: 12, color: "#ffffff" }).setPosition(this.king.x, this.king.y - 50).setOrigin(0.5, 0.5);
    }
  }
  updateBase() {
    var _a, _b, _c, _d;
    if (this.king) {
      (_a = this.tipText) == null ? void 0 : _a.setPosition(this.king.x, this.king.y - 50);
      this.king.update();
    }
    (_b = this.pigs) == null ? void 0 : _b.forEach((pig) => {
      pig.update();
    });
    (_c = this.coins) == null ? void 0 : _c.forEach((coin) => {
      coin.update();
    });
    (_d = this.gameManage) == null ? void 0 : _d.update();
  }
}
class TestScene extends Phaser.Scene {
  constructor() {
    super("TestScene");
    __publicField(this, "gameManage");
  }
  create() {
    this.gameManage = new GameManage(this, 100, 100, "livesAndCoinsSheet", 0);
  }
  update() {
    this.gameManage.update();
  }
}
const _sfc_main = {
  __name: "kingandpigs",
  __ssrInlineRender: true,
  setup(__props) {
    const kingAndPigs = ref(null);
    useNuxtApp();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        ref_key: "kingAndPigs",
        ref: kingAndPigs,
        id: "kingAndPigs"
      }, _attrs))} data-v-7a00f9c0></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/game/kingandpigs.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const kingandpigs = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-7a00f9c0"]]);

export { kingandpigs as default };
//# sourceMappingURL=kingandpigs-3584a107.mjs.map
