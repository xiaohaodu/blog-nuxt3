import { b as buildAssetsURL } from './renderer.mjs';
import { ref, onUnmounted, mergeProps, useSSRContext } from 'vue';
import { _ as _export_sfc, g as useNuxtApp } from './server.mjs';
import { ssrRenderAttrs } from 'vue/server-renderer';
import Phaser from 'phaser';
import 'vue-bundle-renderer/runtime';
import 'h3';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@vue/shared';
import 'lodash-unified';
import '@vueuse/core';

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
const target = "" + buildAssetsURL("target.5d9371ea.png");
const knife = "" + buildAssetsURL("knife.5bfe92d2.png");
class playGame extends Phaser.Scene {
  constructor() {
    super("playGame");
    __publicField(this, "gameOptions", {
      // 设置旋转速度，即每一帧转动的角度
      rotationSpeed: 3,
      // 刀飞出去的速度, 即一秒中内移动像素
      throwSpeed: 150,
      //v1.1新增 两把刀之前的最小角度(约束角度)
      minAngle: 15,
      //v1.2新增 最大转动的变化量，即每一帧上限
      rotationVariation: 2,
      //v1.2新增 下一秒的变化速度
      changeTime: 2e3,
      //v1.2新增 最大旋转速度
      maxRotationSpeed: 6
    });
  }
  // 预加载
  preload() {
    this.load.image("target", target);
    this.load.image("knife", knife);
  }
  // 游戏开始运行
  create() {
    this.currentRotationSpeed = this.gameOptions.rotationSpeed;
    this.newRotationSpeed = this.gameOptions.rotationSpeed;
    this.canThrow = true;
    this.knifeGroup = this.add.group();
    this.knife = this.add.sprite(this.game.config.width / 2, this.game.config.height / 5 * 4, "knife");
    this.target = this.add.sprite(this.game.config.width / 2, 400, "target");
    this.target.depth = 1;
    this.input.on("pointerdown", this.throwKnife, this);
    this.time.addEvent({
      delay: this.gameOptions.changeTime,
      callback: this.changeSpeed,
      callbackScope: this,
      loop: true
    });
  }
  //v1.2 圆木的旋转速度
  changeSpeed() {
    const sign = Phaser.Math.Between(0, 1) == 0 ? -1 : 1;
    const variation = Phaser.Math.FloatBetween(-this.gameOptions.rotationVariation, this.gameOptions.rotationVariation);
    this.newRotationSpeed = (this.currentRotationSpeed + variation) * sign;
    this.newRotationSpeed = Phaser.Math.Clamp(this.newRotationSpeed, -this.gameOptions.maxRotationSpeed, this.gameOptions.maxRotationSpeed);
  }
  // 飞出刀动作
  throwKnife() {
    if (this.canThrow) {
      this.canThrow = false;
      this.tweens.add({
        // 刀
        targets: [this.knife],
        // 到达的位置
        y: this.target.y + this.target.width / 2,
        // 补间速度
        duration: this.gameOptions.throwSpeed,
        // 回传范围
        callbackScope: this,
        // 执行后的回调函数
        onComplete: function(tween) {
          let legalHit = true;
          const children = this.knifeGroup.getChildren();
          for (let i = 0; i < children.length; i++) {
            if (Math.abs(Phaser.Math.Angle.ShortestBetween(this.target.angle, children[i].impactAngle)) < this.gameOptions.minAngle) {
              legalHit = false;
              break;
            }
          }
          if (legalHit) {
            this.canThrow = true;
            const knife2 = this.add.sprite(this.knife.x, this.knife.y, "knife");
            knife2.impactAngle = this.target.angle;
            this.knifeGroup.add(knife2);
            this.knife.y = this.game.config.height / 5 * 4;
          } else {
            this.tweens.add({
              //v1.1 目标
              targets: [this.knife],
              y: this.game.config.height + this.knife.height,
              //v1.1 旋转角度
              rotation: 5,
              //v1.1 补间速度 
              duration: this.gameOptions.throwSpeed * 4,
              //v1.1 回传范围
              callbackScope: this,
              //v1.1 结束后的回调函数
              onComplete: function(tween2) {
                this.scene.start("playGame");
              }
            });
          }
        }
      });
    }
  }
  // 游戏每一帧执行 v1.2 增加两个参数
  //update(){
  update(time, delta) {
    console.log("update");
    this.target.angle += this.currentRotationSpeed;
    const children = this.knifeGroup.getChildren();
    for (let i = 0; i < children.length; i++) {
      children[i].angle += this.currentRotationSpeed;
      const radians = Phaser.Math.DegToRad(children[i].angle + 90);
      children[i].x = this.target.x + this.target.width / 2 * Math.cos(radians);
      children[i].y = this.target.y + this.target.width / 2 * Math.sin(radians);
    }
    this.currentRotationSpeed = Phaser.Math.Linear(this.currentRotationSpeed, this.newRotationSpeed, delta / 1e3);
  }
}
const _sfc_main = {
  __name: "knifehit",
  __ssrInlineRender: true,
  setup(__props) {
    let game;
    const knifehit2 = ref(null);
    useNuxtApp();
    onUnmounted(() => {
      window.removeEventListener("resize", resize);
    });
    function resize() {
      const canvas = document.querySelector("canvas");
      const windowWidth = window.innerWidth;
      const windowHeight = window.innerHeight;
      const windowRatio = windowWidth / windowHeight;
      const gameRatio = game.config.width / game.config.height;
      if (windowRatio < gameRatio) {
        canvas.style.width = windowWidth + "px";
        canvas.style.height = windowWidth / gameRatio + "px";
      } else {
        canvas.style.width = windowHeight * gameRatio + "px";
        canvas.style.height = windowHeight + "px";
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        ref_key: "knifehit",
        ref: knifehit2,
        id: "knifehit"
      }, _attrs))} data-v-f3ff41aa></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/game/knifehit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const knifehit = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-f3ff41aa"]]);

export { knifehit as default };
//# sourceMappingURL=knifehit-092a8b3d.mjs.map
