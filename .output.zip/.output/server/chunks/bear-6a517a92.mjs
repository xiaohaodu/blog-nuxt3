import { ref, mergeProps, useSSRContext } from 'vue';
import { _ as _export_sfc, g as useNuxtApp } from './server.mjs';
import { ssrRenderAttrs } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import '@vue/shared';
import 'lodash-unified';
import '@vueuse/core';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'defu';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {
  __name: "bear",
  __ssrInlineRender: true,
  setup(__props) {
    const container = ref(null);
    useNuxtApp();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        ref_key: "container",
        ref: container,
        id: "container"
      }, _attrs))} data-v-140afdd6></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/three/bear.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const bear = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-140afdd6"]]);

export { bear as default };
//# sourceMappingURL=bear-6a517a92.mjs.map
