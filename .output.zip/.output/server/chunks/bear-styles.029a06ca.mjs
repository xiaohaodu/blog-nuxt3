const bear_vue_vue_type_style_index_0_scoped_140afdd6_lang = "#container[data-v-140afdd6]{height:100vh;overflow:hidden;width:100vw}";

const bearStyles_029a06ca = [bear_vue_vue_type_style_index_0_scoped_140afdd6_lang];

export { bearStyles_029a06ca as default };
//# sourceMappingURL=bear-styles.029a06ca.mjs.map
