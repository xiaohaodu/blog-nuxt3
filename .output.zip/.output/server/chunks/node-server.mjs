globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import 'node-fetch-native/polyfill';
import { Server as Server$1 } from 'node:http';
import { Server } from 'node:https';
import destr from 'destr';
import { defineEventHandler, handleCacheHeaders, createEvent, eventHandler, setHeaders, sendRedirect, proxyRequest, getRequestHeader, setResponseStatus, setResponseHeader, getRequestHeaders, createError, createApp, createRouter as createRouter$1, toNodeListener, fetchWithEvent, lazyEventHandler } from 'h3';
import { createFetch as createFetch$1, Headers } from 'ofetch';
import { createCall, createFetch } from 'unenv/runtime/fetch/index';
import { createHooks } from 'hookable';
import { snakeCase } from 'scule';
import defu, { defuFn } from 'defu';
import { hash } from 'ohash';
import { parseURL, withoutBase, joinURL, withQuery, withLeadingSlash, withoutTrailingSlash } from 'ufo';
import { createStorage, prefixStorage } from 'unstorage';
import { toRouteMatcher, createRouter } from 'radix3';
import { promises } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'pathe';

const inlineAppConfig = {};



const appConfig = defuFn(inlineAppConfig);

const _runtimeConfig = {"app":{"baseURL":"/","buildAssetsDir":"/_nuxt/","cdnURL":""},"nitro":{"envPrefix":"NUXT_","routeRules":{"/__nuxt_error":{"cache":false},"/three/**":{"ssr":false},"/game/**":{"ssr":false},"/_nuxt/**":{"headers":{"cache-control":"public, max-age=31536000, immutable"}}}},"public":{}};
const ENV_PREFIX = "NITRO_";
const ENV_PREFIX_ALT = _runtimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_";
overrideConfig(_runtimeConfig);
const runtimeConfig = deepFreeze(_runtimeConfig);
const useRuntimeConfig = () => runtimeConfig;
deepFreeze(appConfig);
function getEnv(key) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[ENV_PREFIX + envKey] ?? process.env[ENV_PREFIX_ALT + envKey]
  );
}
function isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function overrideConfig(obj, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey);
    if (isObject(obj[key])) {
      if (isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
      }
      overrideConfig(obj[key], subKey);
    } else {
      obj[key] = envValue ?? obj[key];
    }
  }
}
function deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      deepFreeze(value);
    }
  }
  return Object.freeze(object);
}

const _assets = {

};

function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
}

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

const storage = createStorage({});

storage.mount('/assets', assets$1);

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = hash([opts.integrity, fn, opts]);
  const validate = opts.validate || (() => true);
  async function get(key, resolver, shouldInvalidateCache) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    const entry = await useStorage().getItem(cacheKey) || {};
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || !validate(entry);
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry)) {
          useStorage().setItem(cacheKey, entry).catch((error) => console.error("[nitro] [cache]", error));
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (opts.swr && entry.value) {
      _resolvePromise.catch(console.error);
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = opts.shouldInvalidateCache?.(...args);
    const entry = await get(key, () => fn(...args), shouldInvalidateCache);
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length > 0 ? hash(args, {}) : "";
}
function escapeKey(key) {
  return key.replace(/[^\dA-Za-z]/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const key = await opts.getKey?.(event);
      if (key) {
        return escapeKey(key);
      }
      const url = event.node.req.originalUrl || event.node.req.url;
      const friendlyName = escapeKey(decodeURI(parseURL(url).pathname)).slice(
        0,
        16
      );
      const urlHash = hash(url);
      return `${friendlyName}.${urlHash}`;
    },
    validate: (entry) => {
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: [opts.integrity, handler]
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const reqProxy = cloneWithProxy(incomingEvent.node.req, { headers: {} });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            for (const header in headers2) {
              this.setHeader(header, headers2[header]);
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.context = incomingEvent.context;
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = headers.Etag || headers.etag || `W/"${hash(body)}"`;
      headers["last-modified"] = headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString();
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(event);
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      event.node.res.setHeader(name, response.headers[name]);
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler() {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      return sendRedirect(
        event,
        routeRules.redirect.to,
        routeRules.redirect.statusCode
      );
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      }
      return proxyRequest(event, target, {
        fetch: $fetch.raw,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    const path = new URL(event.node.req.url, "http://localhost").pathname;
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(path, useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

const plugins = [
  
];

function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function normalizeError(error) {
  const cwd = typeof process.cwd === "function" ? process.cwd() : "/";
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Not Found" : "");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}

const errorHandler = (async function errorhandler(error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(error);
  const errorObject = {
    url: event.node.req.url,
    statusCode,
    statusMessage,
    message,
    stack: "",
    data: error.data
  };
  setResponseStatus(event, errorObject.statusCode !== 200 && errorObject.statusCode || 500, errorObject.statusMessage);
  if (error.unhandled || error.fatal) {
    const tags = [
      "[nuxt]",
      "[request error]",
      error.unhandled && "[unhandled]",
      error.fatal && "[fatal]",
      Number(errorObject.statusCode) !== 200 && `[${errorObject.statusCode}]`
    ].filter(Boolean).join(" ");
    console.error(tags, errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (isJsonRequest(event)) {
    setResponseHeader(event, "Content-Type", "application/json");
    event.node.res.end(JSON.stringify(errorObject));
    return;
  }
  const isErrorPage = event.node.req.url?.startsWith("/__nuxt_error");
  const res = !isErrorPage ? await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig().app.baseURL, "/__nuxt_error"), errorObject), {
    headers: getRequestHeaders(event),
    redirect: "manual"
  }).catch(() => null) : null;
  if (!res) {
    const { template } = await import('./error-500.mjs');
    setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
    event.node.res.end(template(errorObject));
    return;
  }
  for (const [header, value] of res.headers.entries()) {
    setResponseHeader(event, header, value);
  }
  setResponseStatus(event, res.status && res.status !== 200 ? res.status : void 0, res.statusText);
  event.node.res.end(await res.text());
});

const assets = {
  "/baidu-analytics.js": {
    "type": "application/javascript",
    "etag": "\"10a-N9QLwP29fJxL+VIKFp0WhdkhZl0\"",
    "mtime": "2023-05-07T02:50:14.888Z",
    "size": 266,
    "path": "../public/baidu-analytics.js"
  },
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"10be-n8egyE9tcb7sKGr/pYCaQ4uWqxI\"",
    "mtime": "2023-04-12T12:57:50.732Z",
    "size": 4286,
    "path": "../public/favicon.ico"
  },
  "/theme/github-block-dark.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"652-SeycBRkoQ73EzBjiFRv4QQAgppk\"",
    "mtime": "2023-04-12T12:57:50.733Z",
    "size": 1618,
    "path": "../public/theme/github-block-dark.css"
  },
  "/theme/github-block.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"526-JbSYHEDQrAyOV1U4DFEwpiZbGXQ\"",
    "mtime": "2023-04-12T12:57:50.734Z",
    "size": 1318,
    "path": "../public/theme/github-block.css"
  },
  "/theme/github.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1bab-7SJ78nLsQpjunYtinlW1sw0flnw\"",
    "mtime": "2023-04-12T12:57:50.734Z",
    "size": 7083,
    "path": "../public/theme/github.css"
  },
  "/theme/night.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3b41-g72WJsCmspJXk4UO5xsMNy2UdQ0\"",
    "mtime": "2023-04-12T12:57:50.740Z",
    "size": 15169,
    "path": "../public/theme/night.css"
  },
  "/theme/theme.scss": {
    "type": "text/x-scss; charset=utf-8",
    "etag": "\"45a-zg9bCuKFXrxvmiwlgf8MEHQ1I94\"",
    "mtime": "2023-04-12T12:57:50.743Z",
    "size": 1114,
    "path": "../public/theme/theme.scss"
  },
  "/_blogs/monorepo.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"c-oPhc6ck1yOrZQUYibcpYoKm/cwI\"",
    "mtime": "2023-06-05T14:43:54.231Z",
    "size": 12,
    "path": "../public/_blogs/monorepo.md"
  },
  "/_blogs/README.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"34e-Wei/8wwxIDKKqEDN34XcmGrPtxI\"",
    "mtime": "2023-05-12T03:04:31.224Z",
    "size": 846,
    "path": "../public/_blogs/README.md"
  },
  "/_blogs/规范Git commit.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"8f6-LQStwwedSraJz6gZU7pHXW4Wk5o\"",
    "mtime": "2023-06-03T03:11:15.623Z",
    "size": 2294,
    "path": "../public/_blogs/规范Git commit.md"
  },
  "/_nuxt/02-KingHuman.ed4978af.png": {
    "type": "image/png",
    "etag": "\"4ae9-vgqWhVokEMGDBoG1ezmVUmbjGYk\"",
    "mtime": "2023-09-24T08:48:12.207Z",
    "size": 19177,
    "path": "../public/_nuxt/02-KingHuman.ed4978af.png"
  },
  "/_nuxt/03-Pig.73ccdc30.png": {
    "type": "image/png",
    "etag": "\"1856-KtM3twclqMpfELrkwzVCh63FcTg\"",
    "mtime": "2023-09-24T08:48:12.207Z",
    "size": 6230,
    "path": "../public/_nuxt/03-Pig.73ccdc30.png"
  },
  "/_nuxt/04-PigBox.e6f2b402.png": {
    "type": "image/png",
    "etag": "\"135a-wUuiopEeQJQWg9jXPaag+w/JVlA\"",
    "mtime": "2023-09-24T08:48:12.207Z",
    "size": 4954,
    "path": "../public/_nuxt/04-PigBox.e6f2b402.png"
  },
  "/_nuxt/05-PigBoom.9b30afbb.png": {
    "type": "image/png",
    "etag": "\"14ee-bDZCsVW9Kagoyq0eQVkM2f8qGzU\"",
    "mtime": "2023-09-24T08:48:12.207Z",
    "size": 5358,
    "path": "../public/_nuxt/05-PigBoom.9b30afbb.png"
  },
  "/_nuxt/06-PigHide.57a37b2d.png": {
    "type": "image/png",
    "etag": "\"748-lMVq21YN0oXhh7Bqh6f/A/zvtJU\"",
    "mtime": "2023-09-24T08:48:12.207Z",
    "size": 1864,
    "path": "../public/_nuxt/06-PigHide.57a37b2d.png"
  },
  "/_nuxt/07-KingPig.7d054137.png": {
    "type": "image/png",
    "etag": "\"1cac-OMMKk4zz+ONmmrTsQfNbCvt2e1I\"",
    "mtime": "2023-09-24T08:48:12.207Z",
    "size": 7340,
    "path": "../public/_nuxt/07-KingPig.7d054137.png"
  },
  "/_nuxt/11-Door.a4369bda.png": {
    "type": "image/png",
    "etag": "\"11fc-v/oSHbjy2FLTqcwk1vOk0yZh3Jw\"",
    "mtime": "2023-09-24T08:48:12.207Z",
    "size": 4604,
    "path": "../public/_nuxt/11-Door.a4369bda.png"
  },
  "/_nuxt/12-Lives and Coins.f1f4bf3e.png": {
    "type": "image/png",
    "etag": "\"12a8-FcAntKaDI6W8yLgNIr5KcsFHzIM\"",
    "mtime": "2023-09-24T08:48:12.207Z",
    "size": 4776,
    "path": "../public/_nuxt/12-Lives and Coins.f1f4bf3e.png"
  },
  "/_nuxt/bear.3ab1d705.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"46-wIzE2J8pZscnUn5BaUx34KeK9dk\"",
    "mtime": "2023-09-24T08:48:12.215Z",
    "size": 70,
    "path": "../public/_nuxt/bear.3ab1d705.css"
  },
  "/_nuxt/bear.d083884b.js": {
    "type": "application/javascript",
    "etag": "\"ad69-co91MuyTTexi0Tk7xVM9ekxCMgc\"",
    "mtime": "2023-09-24T08:48:12.226Z",
    "size": 44393,
    "path": "../public/_nuxt/bear.d083884b.js"
  },
  "/_nuxt/box.4aaa6606.js": {
    "type": "application/javascript",
    "etag": "\"305-vkaOei/pJuu94Qo4D044NX1abNE\"",
    "mtime": "2023-09-24T08:48:12.225Z",
    "size": 773,
    "path": "../public/_nuxt/box.4aaa6606.js"
  },
  "/_nuxt/box.752689c6.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"46-+oOtdi//hEwMf9+eIvBChC3Zy4E\"",
    "mtime": "2023-09-24T08:48:12.208Z",
    "size": 70,
    "path": "../public/_nuxt/box.752689c6.css"
  },
  "/_nuxt/breakout.3fa08eef.js": {
    "type": "application/javascript",
    "etag": "\"1464-KUW1I9faQGjDsJgvsu68uGW3MHw\"",
    "mtime": "2023-09-24T08:48:12.225Z",
    "size": 5220,
    "path": "../public/_nuxt/breakout.3fa08eef.js"
  },
  "/_nuxt/breakout.89c18acf.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"57-emGtiNf0UQ+v3HVZ/o0XWoHtH7E\"",
    "mtime": "2023-09-24T08:48:12.214Z",
    "size": 87,
    "path": "../public/_nuxt/breakout.89c18acf.css"
  },
  "/_nuxt/breakout.cfc50a67.png": {
    "type": "image/png",
    "etag": "\"2196-8QH2U+/f5LUkf0Kg3sgMA6DDKZI\"",
    "mtime": "2023-09-24T08:48:12.202Z",
    "size": 8598,
    "path": "../public/_nuxt/breakout.cfc50a67.png"
  },
  "/_nuxt/entry.2ccb60ff.js": {
    "type": "application/javascript",
    "etag": "\"6afe3-cDBbFibg7Cen3P0Yp9h4FqYyJoI\"",
    "mtime": "2023-09-24T08:48:12.226Z",
    "size": 438243,
    "path": "../public/_nuxt/entry.2ccb60ff.js"
  },
  "/_nuxt/entry.6f86fc6b.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"512e-olj508c2nrQN0yXwvEoNuXVrtYs\"",
    "mtime": "2023-09-24T08:48:12.215Z",
    "size": 20782,
    "path": "../public/_nuxt/entry.6f86fc6b.css"
  },
  "/_nuxt/error-component.15b8b555.js": {
    "type": "application/javascript",
    "etag": "\"1f7-J2WyYksvmYgPTXrJ9pUOIUCOSR8\"",
    "mtime": "2023-09-24T08:48:12.225Z",
    "size": 503,
    "path": "../public/_nuxt/error-component.15b8b555.js"
  },
  "/_nuxt/error-component.62a04b01.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"109-VI0DqbtQ1QMbDjyVaPE+fJacn6M\"",
    "mtime": "2023-09-24T08:48:12.208Z",
    "size": 265,
    "path": "../public/_nuxt/error-component.62a04b01.css"
  },
  "/_nuxt/icon-github-light.aff36099.svg": {
    "type": "image/svg+xml",
    "etag": "\"32a-OOijH0d5WhSQfSaHkmu171I4vOE\"",
    "mtime": "2023-09-24T08:48:12.208Z",
    "size": 810,
    "path": "../public/_nuxt/icon-github-light.aff36099.svg"
  },
  "/_nuxt/icon-github-night.380c169b.svg": {
    "type": "image/svg+xml",
    "etag": "\"32a-9Shjm6BrtU0El9O33sZlzDQkOdw\"",
    "mtime": "2023-09-24T08:48:12.208Z",
    "size": 810,
    "path": "../public/_nuxt/icon-github-night.380c169b.svg"
  },
  "/_nuxt/index.063809d7.js": {
    "type": "application/javascript",
    "etag": "\"179-mLfZIOOSRuBV+l3f+iwy/XeUZug\"",
    "mtime": "2023-09-24T08:48:12.218Z",
    "size": 377,
    "path": "../public/_nuxt/index.063809d7.js"
  },
  "/_nuxt/kingandpigs.42c3139b.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"5a-NmjO+VlQCFSojA1Y1W+9Kh0meSo\"",
    "mtime": "2023-09-24T08:48:12.214Z",
    "size": 90,
    "path": "../public/_nuxt/kingandpigs.42c3139b.css"
  },
  "/_nuxt/kingandpigs.7b5eefae.js": {
    "type": "application/javascript",
    "etag": "\"e663-zEL+qv80GSdQGavVBwmBv73FoJ8\"",
    "mtime": "2023-09-24T08:48:12.225Z",
    "size": 58979,
    "path": "../public/_nuxt/kingandpigs.7b5eefae.js"
  },
  "/_nuxt/knife.5bfe92d2.png": {
    "type": "image/png",
    "etag": "\"37dc-JfvjQhKBh9P5dJb4VHKTfxEf1no\"",
    "mtime": "2023-09-24T08:48:12.207Z",
    "size": 14300,
    "path": "../public/_nuxt/knife.5bfe92d2.png"
  },
  "/_nuxt/knifehit.579d380f.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"57-1V71xKeywggqU6xW5/2xbooTSek\"",
    "mtime": "2023-09-24T08:48:12.213Z",
    "size": 87,
    "path": "../public/_nuxt/knifehit.579d380f.css"
  },
  "/_nuxt/knifehit.d7b6bad4.js": {
    "type": "application/javascript",
    "etag": "\"d72-2lI2TPGwwnjoZSOS2kLE2/9Sftg\"",
    "mtime": "2023-09-24T08:48:12.225Z",
    "size": 3442,
    "path": "../public/_nuxt/knifehit.d7b6bad4.js"
  },
  "/_nuxt/moon.e4bb930d.svg": {
    "type": "image/svg+xml",
    "etag": "\"2d3-lcChqsCFtYYq1LSbYyYlh8adL1g\"",
    "mtime": "2023-09-24T08:48:12.208Z",
    "size": 723,
    "path": "../public/_nuxt/moon.e4bb930d.svg"
  },
  "/_nuxt/NotFound.136cb9fe.svg": {
    "type": "image/svg+xml",
    "etag": "\"fd6a-FDwJq1jTQfXCglAAgch9R+0ouzE\"",
    "mtime": "2023-09-24T08:48:12.208Z",
    "size": 64874,
    "path": "../public/_nuxt/NotFound.136cb9fe.svg"
  },
  "/_nuxt/nuxt-link.378513cd.js": {
    "type": "application/javascript",
    "etag": "\"10dc-0519TaA7spnW30w8PmpMxkEB+a4\"",
    "mtime": "2023-09-24T08:48:12.225Z",
    "size": 4316,
    "path": "../public/_nuxt/nuxt-link.378513cd.js"
  },
  "/_nuxt/OrbitControls.b7cf5ddf.js": {
    "type": "application/javascript",
    "etag": "\"771c1-TN+UABCF1bjjFbJA11DLhWqYcJ8\"",
    "mtime": "2023-09-24T08:48:12.226Z",
    "size": 487873,
    "path": "../public/_nuxt/OrbitControls.b7cf5ddf.js"
  },
  "/_nuxt/phaser.888dcb6c.js": {
    "type": "application/javascript",
    "etag": "\"160c15-yknNnUaWJdAN4t62OGm/OP+umhY\"",
    "mtime": "2023-09-24T08:48:12.227Z",
    "size": 1444885,
    "path": "../public/_nuxt/phaser.888dcb6c.js"
  },
  "/_nuxt/sun.f196a66a.svg": {
    "type": "image/svg+xml",
    "etag": "\"44b-KUim0wDGLyQkwef1/Dcc8zPn53k\"",
    "mtime": "2023-09-24T08:48:12.208Z",
    "size": 1099,
    "path": "../public/_nuxt/sun.f196a66a.svg"
  },
  "/_nuxt/target.5d9371ea.png": {
    "type": "image/png",
    "etag": "\"2b5b5-mZdgR4HJDmeFixYVlxXsa6U6gAU\"",
    "mtime": "2023-09-24T08:48:12.207Z",
    "size": 177589,
    "path": "../public/_nuxt/target.5d9371ea.png"
  },
  "/_nuxt/Terrain(32x32).5cda6d4e.png": {
    "type": "image/png",
    "etag": "\"5966-3aYWW6I8oLH9q1HmkJUmfBjhcmE\"",
    "mtime": "2023-09-24T08:48:12.207Z",
    "size": 22886,
    "path": "../public/_nuxt/Terrain(32x32).5cda6d4e.png"
  },
  "/_nuxt/vrhouse.5fee50cb.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"46-b9oVMv9AkPuxSCOLHnnhHsmR2WA\"",
    "mtime": "2023-09-24T08:48:12.208Z",
    "size": 70,
    "path": "../public/_nuxt/vrhouse.5fee50cb.css"
  },
  "/_nuxt/vrhouse.6288d027.js": {
    "type": "application/javascript",
    "etag": "\"1147-m7UNtIt70dx4Vw3Zl8Sl6sX7EIk\"",
    "mtime": "2023-09-24T08:48:12.225Z",
    "size": 4423,
    "path": "../public/_nuxt/vrhouse.6288d027.js"
  },
  "/_nuxt/_blogPath_.6b1c59f6.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"9ff-ooPZ2HoeeORF7zRpJOAMa9rp9QM\"",
    "mtime": "2023-09-24T08:48:12.215Z",
    "size": 2559,
    "path": "../public/_nuxt/_blogPath_.6b1c59f6.css"
  },
  "/_nuxt/_blogPath_.c10aec2d.js": {
    "type": "application/javascript",
    "etag": "\"f21ec-yp8EADHRB/fIAdqPWgqXvGVs1zk\"",
    "mtime": "2023-09-24T08:48:12.226Z",
    "size": 991724,
    "path": "../public/_nuxt/_blogPath_.c10aec2d.js"
  },
  "/_nuxt/_commonjsHelpers.28e086c5.js": {
    "type": "application/javascript",
    "etag": "\"81-C8N1nZQHhv0DyCQ+8q372xaksTY\"",
    "mtime": "2023-09-24T08:48:12.215Z",
    "size": 129,
    "path": "../public/_nuxt/_commonjsHelpers.28e086c5.js"
  },
  "/assets/bear/bear.gltf": {
    "type": "model/gltf+json",
    "etag": "\"edbd7-NBpxxSAY/EGmANvev0G1g5RcFws\"",
    "mtime": "2023-04-27T11:15:04.976Z",
    "size": 973783,
    "path": "../public/assets/bear/bear.gltf"
  },
  "/assets/bear/bg.jpg": {
    "type": "image/jpeg",
    "etag": "\"a2ef4-LhhqZXlmQdu57D0x52QwMxIXv/8\"",
    "mtime": "2023-04-27T11:15:04.983Z",
    "size": 667380,
    "path": "../public/assets/bear/bg.jpg"
  },
  "/assets/vrhouse/Living.hdr": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"14cfc33-XkYN1/MEV0PjomkQJ3+AnZkQLO0\"",
    "mtime": "2023-04-27T11:15:05.175Z",
    "size": 21822515,
    "path": "../public/assets/vrhouse/Living.hdr"
  },
  "/theme/github/300.woff": {
    "type": "font/woff",
    "etag": "\"10f10-PNLPhvq9NWtV7V9fXqvQ7sEW5gI\"",
    "mtime": "2023-04-12T12:57:50.736Z",
    "size": 69392,
    "path": "../public/theme/github/300.woff"
  },
  "/theme/github/400.woff": {
    "type": "font/woff",
    "etag": "\"107c4-hDnKMJCSQAiWDLRHRkToWWWEPBU\"",
    "mtime": "2023-04-12T12:57:50.736Z",
    "size": 67524,
    "path": "../public/theme/github/400.woff"
  },
  "/theme/github/400i.woff": {
    "type": "font/woff",
    "etag": "\"fea0-pdGLv+I5g8jESQ99FKyDKIouXZ4\"",
    "mtime": "2023-04-12T12:57:50.738Z",
    "size": 65184,
    "path": "../public/theme/github/400i.woff"
  },
  "/theme/github/600i.woff": {
    "type": "font/woff",
    "etag": "\"10160-lv8hB5HvF+RH0uEvQie8rjY5ImY\"",
    "mtime": "2023-04-12T12:57:50.739Z",
    "size": 65888,
    "path": "../public/theme/github/600i.woff"
  },
  "/theme/github/700.woff": {
    "type": "font/woff",
    "etag": "\"1122c-swT4ShFFOtIQ0AawUVAHCDx6EB8\"",
    "mtime": "2023-04-12T12:57:50.740Z",
    "size": 70188,
    "path": "../public/theme/github/700.woff"
  },
  "/theme/github/700i.woff": {
    "type": "font/woff",
    "etag": "\"fe24-FerMMJaqsz2NIH0gwKMQDOBRVcU\"",
    "mtime": "2023-04-12T12:57:50.740Z",
    "size": 65060,
    "path": "../public/theme/github/700i.woff"
  },
  "/theme/night/codeblock.dark.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"632-E0BaJxXW/bXQshj5mnJmL1S/hBs\"",
    "mtime": "2023-04-12T12:57:50.742Z",
    "size": 1586,
    "path": "../public/theme/night/codeblock.dark.css"
  },
  "/theme/night/credit.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"127-OhqMIlEmW0nbPoibCi7IUDrGJ8c\"",
    "mtime": "2023-04-12T12:57:50.743Z",
    "size": 295,
    "path": "../public/theme/night/credit.html"
  },
  "/theme/night/cursor.png": {
    "type": "image/png",
    "etag": "\"174-DSXI+nHvVycuTqG3jJdbuC/ZXYI\"",
    "mtime": "2023-04-12T12:57:50.743Z",
    "size": 372,
    "path": "../public/theme/night/cursor.png"
  },
  "/theme/night/cursor@2x.png": {
    "type": "image/png",
    "etag": "\"197-afwOsUd7F0D8aut9rn1N3gDV0rM\"",
    "mtime": "2023-04-12T12:57:50.743Z",
    "size": 407,
    "path": "../public/theme/night/cursor@2x.png"
  },
  "/theme/night/mermaid.dark.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"117b-+LaYeNXS3aMN0kyERW23PSsBgwQ\"",
    "mtime": "2023-04-12T12:57:50.743Z",
    "size": 4475,
    "path": "../public/theme/night/mermaid.dark.css"
  },
  "/theme/night/sourcemode.dark.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2ef-ElaJPrI4xJNYG3CZ8E2wPbZVQvU\"",
    "mtime": "2023-04-12T12:57:50.743Z",
    "size": 751,
    "path": "../public/theme/night/sourcemode.dark.css"
  },
  "/_blogs/AcWing/快速排序与归并排序与二分查找.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"e67-ZUBh0yh9+wnyyE5V37Fk+0ccMSY\"",
    "mtime": "2023-05-19T13:55:29.484Z",
    "size": 3687,
    "path": "../public/_blogs/AcWing/快速排序与归并排序与二分查找.md"
  },
  "/_blogs/AcWing/深度优先搜索（DFS）.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"b4f-4mJ4UAGE7RKBROFS5xCIto8B3Po\"",
    "mtime": "2023-06-05T15:46:22.233Z",
    "size": 2895,
    "path": "../public/_blogs/AcWing/深度优先搜索（DFS）.md"
  },
  "/_blogs/AcWing/高精度.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"3ee-WPufONLDfcyAvfWTBl7dZS12hz4\"",
    "mtime": "2023-05-19T14:16:43.044Z",
    "size": 1006,
    "path": "../public/_blogs/AcWing/高精度.md"
  },
  "/_blogs/CSS/CSS相关问题合集.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"135c-/WBrZ7iSk34xgo3c3kcUYl8XZU8\"",
    "mtime": "2023-05-22T06:50:03.060Z",
    "size": 4956,
    "path": "../public/_blogs/CSS/CSS相关问题合集.md"
  },
  "/_blogs/CSS/flex布局与grid布局.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"9ea-AZ37UApOSZR5hxeQr6ZaV0k/95g\"",
    "mtime": "2023-05-18T11:26:02.970Z",
    "size": 2538,
    "path": "../public/_blogs/CSS/flex布局与grid布局.md"
  },
  "/_blogs/JavaScript/apply和call和bind.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"c09-u9DJpOQPo8WucxzM6l5So49BZX0\"",
    "mtime": "2023-05-21T02:54:15.697Z",
    "size": 3081,
    "path": "../public/_blogs/JavaScript/apply和call和bind.md"
  },
  "/_blogs/JavaScript/Array.isArray和instanceof.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"574-KgFh5QyVtzz9OPdO7xKByKLmtvs\"",
    "mtime": "2023-05-25T12:28:05.582Z",
    "size": 1396,
    "path": "../public/_blogs/JavaScript/Array.isArray和instanceof.md"
  },
  "/_blogs/JavaScript/freeze对象冻结.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"161-RSCcIg+Q8hfBIwtJsBfwmK3HaNk\"",
    "mtime": "2023-05-24T12:06:59.258Z",
    "size": 353,
    "path": "../public/_blogs/JavaScript/freeze对象冻结.md"
  },
  "/_blogs/JavaScript/JavaScript相关问题合集.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"315-iFSWxEoSyFKip3ig7rFo56aoEZ4\"",
    "mtime": "2023-05-22T06:57:16.717Z",
    "size": 789,
    "path": "../public/_blogs/JavaScript/JavaScript相关问题合集.md"
  },
  "/_blogs/JavaScript/JS闭包.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"bcc-EPpFksH20UiAswdx/MEoU8Vz23Q\"",
    "mtime": "2023-05-21T00:52:48.647Z",
    "size": 3020,
    "path": "../public/_blogs/JavaScript/JS闭包.md"
  },
  "/_blogs/JavaScript/JS防抖和节流.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"f42-HGCW53adU3u0zGUpeJRAsHO0UCc\"",
    "mtime": "2023-05-24T13:46:52.302Z",
    "size": 3906,
    "path": "../public/_blogs/JavaScript/JS防抖和节流.md"
  },
  "/_blogs/JavaScript/Promise.all实现.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"3ad-fUZ9nD9nHMtBCdTFwiPDP5RQy7Q\"",
    "mtime": "2023-05-24T14:59:57.559Z",
    "size": 941,
    "path": "../public/_blogs/JavaScript/Promise.all实现.md"
  },
  "/_blogs/JavaScript/Random Permutation（均匀随机排列算法）.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"c66-jFrHGvucFTTY8K1rxBH0OiMtW8Q\"",
    "mtime": "2023-05-24T16:09:55.276Z",
    "size": 3174,
    "path": "../public/_blogs/JavaScript/Random Permutation（均匀随机排列算法）.md"
  },
  "/_blogs/JavaScript/reflow和repaint.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"697-PikVPbDrtdVqlBEcBsewtEqNemk\"",
    "mtime": "2023-05-22T13:57:07.484Z",
    "size": 1687,
    "path": "../public/_blogs/JavaScript/reflow和repaint.md"
  },
  "/_blogs/JavaScript/setTimeout、setInterval 和requestAnimationFrame 之间的区别.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"fe0-FA3RVY5jk2UnyW7Mw5oXkBiXFXg\"",
    "mtime": "2023-05-22T13:40:42.274Z",
    "size": 4064,
    "path": "../public/_blogs/JavaScript/setTimeout、setInterval 和requestAnimationFrame 之间的区别.md"
  },
  "/_blogs/JavaScript/Symbol（具有唯一性）.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"282-SMEcgkAzLHXnSC2IcDfoGk/nh48\"",
    "mtime": "2023-05-24T13:27:33.260Z",
    "size": 642,
    "path": "../public/_blogs/JavaScript/Symbol（具有唯一性）.md"
  },
  "/_blogs/JavaScript/this.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"a39-AEIJdHjAR5f1tZ4KAsxZTSrfiYI\"",
    "mtime": "2023-05-25T02:19:26.488Z",
    "size": 2617,
    "path": "../public/_blogs/JavaScript/this.md"
  },
  "/_blogs/JavaScript/了解微任务、宏任务与Event-Loop.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"1cad-Z0Qv85450B5bZicbAYLdm4gnGKs\"",
    "mtime": "2023-05-22T07:51:38.855Z",
    "size": 7341,
    "path": "../public/_blogs/JavaScript/了解微任务、宏任务与Event-Loop.md"
  },
  "/_blogs/JavaScript/任务队列、动画回调队列、微任务队列.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"241-l3v4i9WGgbKN48IUoArtFUz4TWM\"",
    "mtime": "2023-05-22T13:56:36.373Z",
    "size": 577,
    "path": "../public/_blogs/JavaScript/任务队列、动画回调队列、微任务队列.md"
  },
  "/_blogs/JavaScript/使用JS编写试题（V8和Node环境下的输入输出）.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"48a-aSrY76ek3YUB2PGt5oPJPH7YXjo\"",
    "mtime": "2023-05-29T04:02:58.279Z",
    "size": 1162,
    "path": "../public/_blogs/JavaScript/使用JS编写试题（V8和Node环境下的输入输出）.md"
  },
  "/_blogs/JavaScript/原型与原型链.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"d34-IbIuhFSd8CXvw21WJhRvw8FDmyY\"",
    "mtime": "2023-05-20T13:50:30.534Z",
    "size": 3380,
    "path": "../public/_blogs/JavaScript/原型与原型链.md"
  },
  "/_blogs/JavaScript/原生JS实现事件委托.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"7b5-A4qg79DuJPvhpYuem8mhOHBzYAw\"",
    "mtime": "2023-05-20T13:33:42.602Z",
    "size": 1973,
    "path": "../public/_blogs/JavaScript/原生JS实现事件委托.md"
  },
  "/_blogs/JavaScript/性能优化.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"f0-0bWL+CCzYZsYcndpgerHqFnViek\"",
    "mtime": "2023-05-20T04:15:03.811Z",
    "size": 240,
    "path": "../public/_blogs/JavaScript/性能优化.md"
  },
  "/_blogs/JavaScript/深拷贝与浅拷贝.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"df1-Xw+bZFodtJq6zhQASNCf8Z7EBME\"",
    "mtime": "2023-05-20T12:51:53.241Z",
    "size": 3569,
    "path": "../public/_blogs/JavaScript/深拷贝与浅拷贝.md"
  },
  "/_blogs/leetcode/2618.检查是否是类的对象的实例.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"5b5-lvVL9hImASnM5UlZri+wH7eA9sg\"",
    "mtime": "2023-05-24T10:56:58.948Z",
    "size": 1461,
    "path": "../public/_blogs/leetcode/2618.检查是否是类的对象的实例.md"
  },
  "/_blogs/leetcode/2619.数组原型对象的最后一个元素.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"2c4-UCucHj/IZt2juqBBs4fS/Jhg5T4\"",
    "mtime": "2023-05-24T09:10:40.905Z",
    "size": 708,
    "path": "../public/_blogs/leetcode/2619.数组原型对象的最后一个元素.md"
  },
  "/_blogs/leetcode/2625.扁平化嵌套数组.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"1bd-Ot8+Ic4bLlCWua1sHXBukFFpnSc\"",
    "mtime": "2023-05-25T12:28:11.851Z",
    "size": 445,
    "path": "../public/_blogs/leetcode/2625.扁平化嵌套数组.md"
  },
  "/_blogs/leetcode/2627.函数防抖.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"1d6-cGYs/rJIEuGRemJYXQcPnre9xzg\"",
    "mtime": "2023-05-24T13:43:25.139Z",
    "size": 470,
    "path": "../public/_blogs/leetcode/2627.函数防抖.md"
  },
  "/_blogs/leetcode/2628.完全相等的JSON字符串.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"371-iaGQH7QmqdDV4KPYIxYlgoentMc\"",
    "mtime": "2023-05-26T09:03:18.650Z",
    "size": 881,
    "path": "../public/_blogs/leetcode/2628.完全相等的JSON字符串.md"
  },
  "/_blogs/leetcode/2630.记忆函数Ⅱ 2623.记忆函数.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"321-CLhxbnBBCrwHUqHZ5kHGgIaZgmM\"",
    "mtime": "2023-05-28T13:45:05.822Z",
    "size": 801,
    "path": "../public/_blogs/leetcode/2630.记忆函数Ⅱ 2623.记忆函数.md"
  },
  "/_blogs/leetcode/2632.柯里化.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"3f3-VGkIVoetx14Ilc39kBX9khDMj5A\"",
    "mtime": "2023-05-26T16:42:09.394Z",
    "size": 1011,
    "path": "../public/_blogs/leetcode/2632.柯里化.md"
  },
  "/_blogs/leetcode/2633.将对象转换成为JSON字符串.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"2d4-ErWwDp0o3pxSVKojPDWFNzFkr5A\"",
    "mtime": "2023-05-28T02:17:16.607Z",
    "size": 724,
    "path": "../public/_blogs/leetcode/2633.将对象转换成为JSON字符串.md"
  },
  "/_blogs/leetcode/2636.Promise对象池.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"1e9-UA/I7pFDAiZ5PcoolQR5UwXOYtU\"",
    "mtime": "2023-05-28T04:26:40.769Z",
    "size": 489,
    "path": "../public/_blogs/leetcode/2636.Promise对象池.md"
  },
  "/_blogs/leetcode/2637.有时间限制的Promise对象.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"3a8-VhOtnLXymM2QJcJh5hhu70ztz/0\"",
    "mtime": "2023-05-24T09:13:40.835Z",
    "size": 936,
    "path": "../public/_blogs/leetcode/2637.有时间限制的Promise对象.md"
  },
  "/_blogs/leetcode/2650.设计可取消函数.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"60b-G0GKNZ+udW0qHZN9Zja3kS1t8rw\"",
    "mtime": "2023-05-28T13:38:34.143Z",
    "size": 1547,
    "path": "../public/_blogs/leetcode/2650.设计可取消函数.md"
  },
  "/_blogs/leetcode/2676.节流.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"33d-eIaU5T98XSlaEWKxfFcTc8ZMc20\"",
    "mtime": "2023-05-24T14:35:03.978Z",
    "size": 829,
    "path": "../public/_blogs/leetcode/2676.节流.md"
  },
  "/_blogs/leetcode/2693.使用自定义上下文调用函数.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"197-ujAyTdRlsuLwXtO93Z+IDpWA2cE\"",
    "mtime": "2023-05-24T13:27:22.439Z",
    "size": 407,
    "path": "../public/_blogs/leetcode/2693.使用自定义上下文调用函数.md"
  },
  "/_blogs/Nuxt3/NUXT3使用THREEJS和PHASERJS.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"9e5-mTxMWsRTcLxwrSRIwVMX4PDPF24\"",
    "mtime": "2023-04-29T01:51:39.854Z",
    "size": 2533,
    "path": "../public/_blogs/Nuxt3/NUXT3使用THREEJS和PHASERJS.md"
  },
  "/_blogs/Phaser3/PHASERJS使用注意.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"b2-ceJedIZsZnnluOvqQ9RqA0zcMpo\"",
    "mtime": "2023-04-28T11:56:40.636Z",
    "size": 178,
    "path": "../public/_blogs/Phaser3/PHASERJS使用注意.md"
  },
  "/_blogs/PM2/PM2基本使用.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"493-TuESGJ+5+DR+sOttV7LGtR96A68\"",
    "mtime": "2023-05-09T13:30:16.492Z",
    "size": 1171,
    "path": "../public/_blogs/PM2/PM2基本使用.md"
  },
  "/_blogs/PM2/PM2热更新NUXT3-node-server项目.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"58f-Z9p11sVXDRlMerehN5XvtX5Xk/s\"",
    "mtime": "2023-05-12T03:12:20.729Z",
    "size": 1423,
    "path": "../public/_blogs/PM2/PM2热更新NUXT3-node-server项目.md"
  },
  "/_blogs/PM2/PM2热更新项目出现端口占用而失败的问题.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"19b-4WIuMghmH3yGzOPvIqJvgqku7wg\"",
    "mtime": "2023-05-09T14:07:57.444Z",
    "size": 411,
    "path": "../public/_blogs/PM2/PM2热更新项目出现端口占用而失败的问题.md"
  },
  "/_blogs/safari/在safari中重复报错.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"264-cgetffhD/xFnQJFGAlFIFzY/VbI\"",
    "mtime": "2023-05-07T05:53:37.779Z",
    "size": 612,
    "path": "../public/_blogs/safari/在safari中重复报错.md"
  },
  "/_blogs/TypeScript/TypeScript相关问题.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"5a92-iyYfRWipUTMYFwr7PGaNlVSBBm0\"",
    "mtime": "2023-05-21T12:00:14.459Z",
    "size": 23186,
    "path": "../public/_blogs/TypeScript/TypeScript相关问题.md"
  },
  "/_blogs/Vue/MVC和MVVM.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"119e-Ce31s5Bbzy9u0S2FXlp+pL0Hcc8\"",
    "mtime": "2023-05-21T04:40:09.452Z",
    "size": 4510,
    "path": "../public/_blogs/Vue/MVC和MVVM.md"
  },
  "/_blogs/Vue/v-model原理.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"1377-sX3253nIvb549gU/lj5nVhL4p1o\"",
    "mtime": "2023-05-21T05:38:37.650Z",
    "size": 4983,
    "path": "../public/_blogs/Vue/v-model原理.md"
  },
  "/_blogs/Vue/vue应用.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"765-RMpS2Zi2Wa8DjsM8l+hks/itguo\"",
    "mtime": "2023-05-21T05:53:38.042Z",
    "size": 1893,
    "path": "../public/_blogs/Vue/vue应用.md"
  },
  "/_blogs/Vue/组件事件.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"1ab5-HnvBqIpVloswzM+UHmh7vIydTf4\"",
    "mtime": "2023-05-23T02:06:44.322Z",
    "size": 6837,
    "path": "../public/_blogs/Vue/组件事件.md"
  },
  "/_blogs/WEB开发技术/回流与重绘.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"fef-+low3h9bsxHO1F4UNYKTZFBqkeU\"",
    "mtime": "2023-06-06T03:06:56.922Z",
    "size": 4079,
    "path": "../public/_blogs/WEB开发技术/回流与重绘.md"
  },
  "/_blogs/掘金-字节go语言学习/go语言基础.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"f5a-E+l3c7enKxCHo9FzgGB2ISUJFaY\"",
    "mtime": "2023-05-17T13:27:58.549Z",
    "size": 3930,
    "path": "../public/_blogs/掘金-字节go语言学习/go语言基础.md"
  },
  "/_blogs/掘金-字节go语言学习/go语言进阶与依赖管理.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"2700-owc1SlBcD7GioFXUNLsEIBBZemc\"",
    "mtime": "2023-05-18T12:54:19.247Z",
    "size": 9984,
    "path": "../public/_blogs/掘金-字节go语言学习/go语言进阶与依赖管理.md"
  },
  "/_blogs/掘金-字节go语言学习/高质量编程及编码规范.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"1205-Bx31+sYrvjgzjwcm/07kdoHQP9s\"",
    "mtime": "2023-05-19T08:26:25.325Z",
    "size": 4613,
    "path": "../public/_blogs/掘金-字节go语言学习/高质量编程及编码规范.md"
  },
  "/_blogs/牛客JS/FED23 DOM节点查找.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"312-p7LyUlJ3jKpMrZdUk/QtB8iYLOQ\"",
    "mtime": "2023-06-04T05:25:31.284Z",
    "size": 786,
    "path": "../public/_blogs/牛客JS/FED23 DOM节点查找.md"
  },
  "/_blogs/牛客JS/FED27 时间格式化输出.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"7d0-PafkS4+gO8g23tdejdOxS5FxK7M\"",
    "mtime": "2023-06-04T06:57:14.858Z",
    "size": 2000,
    "path": "../public/_blogs/牛客JS/FED27 时间格式化输出.md"
  },
  "/_blogs/牛客JS/FED29 邮箱字符串判断.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"1c6-2ces9qysl/MpaVOWqh2NP/koZbo\"",
    "mtime": "2023-06-04T07:14:49.483Z",
    "size": 454,
    "path": "../public/_blogs/牛客JS/FED29 邮箱字符串判断.md"
  },
  "/_blogs/牛客JS/FED76 检查重复字符串.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"63a-VRjHCew/PqUSULKHBPr8VHieUXw\"",
    "mtime": "2023-06-06T02:32:31.974Z",
    "size": 1594,
    "path": "../public/_blogs/牛客JS/FED76 检查重复字符串.md"
  }
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _f4b49z = eventHandler((event) => {
  if (event.node.req.method && !METHODS.has(event.node.req.method)) {
    return;
  }
  let id = decodeURIComponent(
    withLeadingSlash(
      withoutTrailingSlash(parseURL(event.node.req.url).pathname)
    )
  );
  let asset;
  const encodingHeader = String(
    event.node.req.headers["accept-encoding"] || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  if (encodings.length > 1) {
    event.node.res.setHeader("Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.node.res.removeHeader("cache-control");
      throw createError({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = event.node.req.headers["if-none-match"] === asset.etag;
  if (ifNotMatch) {
    event.node.res.statusCode = 304;
    event.node.res.end();
    return;
  }
  const ifModifiedSinceH = event.node.req.headers["if-modified-since"];
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.node.res.statusCode = 304;
    event.node.res.end();
    return;
  }
  if (asset.type && !event.node.res.getHeader("Content-Type")) {
    event.node.res.setHeader("Content-Type", asset.type);
  }
  if (asset.etag && !event.node.res.getHeader("ETag")) {
    event.node.res.setHeader("ETag", asset.etag);
  }
  if (asset.mtime && !event.node.res.getHeader("Last-Modified")) {
    event.node.res.setHeader("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.node.res.getHeader("Content-Encoding")) {
    event.node.res.setHeader("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.node.res.getHeader("Content-Length")) {
    event.node.res.setHeader("Content-Length", asset.size);
  }
  return readAsset(id);
});

const _lazy_JAFAGC = () => import('./blogReadme.mjs');
const _lazy_WMCCB7 = () => import('./blogsTree.mjs');
const _lazy_qNtdjx = () => import('./readblog.mjs');
const _lazy_YDYo9C = () => import('./renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _f4b49z, lazy: false, middleware: true, method: undefined },
  { route: '/api/blogReadme', handler: _lazy_JAFAGC, lazy: true, middleware: false, method: undefined },
  { route: '/api/blogsTree', handler: _lazy_WMCCB7, lazy: true, middleware: false, method: undefined },
  { route: '/api/readblog', handler: _lazy_qNtdjx, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_YDYo9C, lazy: true, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_YDYo9C, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const h3App = createApp({
    debug: destr(false),
    onError: errorHandler
  });
  const router = createRouter$1();
  h3App.use(createRouteRulesHandler());
  const localCall = createCall(toNodeListener(h3App));
  const localFetch = createFetch(localCall, globalThis.fetch);
  const $fetch = createFetch$1({
    fetch: localFetch,
    Headers,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(
    eventHandler((event) => {
      const envContext = event.node.req.__unenv__;
      if (envContext) {
        Object.assign(event.context, envContext);
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: $fetch });
    })
  );
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch
  };
  for (const plugin of plugins) {
    plugin(app);
  }
  return app;
}
const nitroApp = createNitroApp();
const useNitroApp = () => nitroApp;

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const s = server.listen(port, host, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const i = s.address();
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${i.family === "IPv6" ? `[${i.address}]` : i.address}:${i.port}${baseURL}`;
  console.log(`Listening ${url}`);
});
{
  process.on(
    "unhandledRejection",
    (err) => console.error("[nitro] [dev] [unhandledRejection] " + err)
  );
  process.on(
    "uncaughtException",
    (err) => console.error("[nitro] [dev] [uncaughtException] " + err)
  );
}
const nodeServer = {};

export { useRuntimeConfig as a, getRouteRules as g, nodeServer as n, useNitroApp as u };
//# sourceMappingURL=node-server.mjs.map
