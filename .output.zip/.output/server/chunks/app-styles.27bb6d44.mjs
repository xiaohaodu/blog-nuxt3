const app_vue_vue_type_style_index_0_lang = "*{box-sizing:border-box;margin:0;padding:0}";

const appStyles_27bb6d44 = [app_vue_vue_type_style_index_0_lang];

export { appStyles_27bb6d44 as default };
//# sourceMappingURL=app-styles.27bb6d44.mjs.map
