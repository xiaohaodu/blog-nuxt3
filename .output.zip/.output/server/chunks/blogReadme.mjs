import { defineEventHandler } from 'h3';
import fs from 'fs';

const blogReadme = defineEventHandler((event) => {
  return new Promise((resolve, reject) => {
    fs.readFile(`public/_blogs/README.md`, "utf-8", (err, data) => {
      if (err) {
        reject(err);
      }
      resolve(data);
    });
  });
});

export { blogReadme as default };
//# sourceMappingURL=blogReadme.mjs.map
