const BlogShow_vue_vue_type_style_index_0_scoped_b7d513c4_lang = "#blogContent[data-v-b7d513c4]{padding:2vh}";

const BlogShowStyles_f344623c = [BlogShow_vue_vue_type_style_index_0_scoped_b7d513c4_lang];

export { BlogShowStyles_f344623c as default };
//# sourceMappingURL=BlogShow-styles.f344623c.mjs.map
