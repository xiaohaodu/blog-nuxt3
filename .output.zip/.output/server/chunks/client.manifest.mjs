const client_manifest = {
  "_OrbitControls.b7cf5ddf.js": {
    "resourceType": "script",
    "module": true,
    "file": "OrbitControls.b7cf5ddf.js"
  },
  "__commonjsHelpers.28e086c5.js": {
    "resourceType": "script",
    "module": true,
    "file": "_commonjsHelpers.28e086c5.js"
  },
  "_nuxt-link.378513cd.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.378513cd.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_phaser.888dcb6c.js": {
    "resourceType": "script",
    "module": true,
    "file": "phaser.888dcb6c.js",
    "imports": [
      "__commonjsHelpers.28e086c5.js"
    ]
  },
  "assets/game/breakout/breakout.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "breakout.cfc50a67.png",
    "src": "assets/game/breakout/breakout.png"
  },
  "assets/game/kingandpigs/AsepriteSheet/02-KingHuman.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "02-KingHuman.ed4978af.png",
    "src": "assets/game/kingandpigs/AsepriteSheet/02-KingHuman.png"
  },
  "assets/game/kingandpigs/AsepriteSheet/03-Pig.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "03-Pig.73ccdc30.png",
    "src": "assets/game/kingandpigs/AsepriteSheet/03-Pig.png"
  },
  "assets/game/kingandpigs/AsepriteSheet/04-PigBox.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "04-PigBox.e6f2b402.png",
    "src": "assets/game/kingandpigs/AsepriteSheet/04-PigBox.png"
  },
  "assets/game/kingandpigs/AsepriteSheet/05-PigBoom.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "05-PigBoom.9b30afbb.png",
    "src": "assets/game/kingandpigs/AsepriteSheet/05-PigBoom.png"
  },
  "assets/game/kingandpigs/AsepriteSheet/06-PigHide.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "06-PigHide.57a37b2d.png",
    "src": "assets/game/kingandpigs/AsepriteSheet/06-PigHide.png"
  },
  "assets/game/kingandpigs/AsepriteSheet/07-KingPig.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "07-KingPig.7d054137.png",
    "src": "assets/game/kingandpigs/AsepriteSheet/07-KingPig.png"
  },
  "assets/game/kingandpigs/AsepriteSheet/11-Door.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "11-Door.a4369bda.png",
    "src": "assets/game/kingandpigs/AsepriteSheet/11-Door.png"
  },
  "assets/game/kingandpigs/AsepriteSheet/12-Lives and Coins.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "12-Lives and Coins.f1f4bf3e.png",
    "src": "assets/game/kingandpigs/AsepriteSheet/12-Lives and Coins.png"
  },
  "assets/game/kingandpigs/MapSource/Terrain(32x32).png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "Terrain(32x32).5cda6d4e.png",
    "src": "assets/game/kingandpigs/MapSource/Terrain(32x32).png"
  },
  "assets/game/knifehit/knife.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "knife.5bfe92d2.png",
    "src": "assets/game/knifehit/knife.png"
  },
  "assets/game/knifehit/target.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "target.5d9371ea.png",
    "src": "assets/game/knifehit/target.png"
  },
  "assets/imgs/NotFound.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "NotFound.136cb9fe.svg",
    "src": "assets/imgs/NotFound.svg"
  },
  "assets/imgs/icon-github-light.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "icon-github-light.aff36099.svg",
    "src": "assets/imgs/icon-github-light.svg"
  },
  "assets/imgs/icon-github-night.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "icon-github-night.380c169b.svg",
    "src": "assets/imgs/icon-github-night.svg"
  },
  "assets/imgs/moon.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "moon.e4bb930d.svg",
    "src": "assets/imgs/moon.svg"
  },
  "assets/imgs/sun.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "sun.f196a66a.svg",
    "src": "assets/imgs/sun.svg"
  },
  "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.6f86fc6b.css",
    "src": "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "moon.e4bb930d.svg",
      "sun.f196a66a.svg",
      "icon-github-light.aff36099.svg",
      "icon-github-night.380c169b.svg"
    ],
    "css": [
      "entry.6f86fc6b.css"
    ],
    "dynamicImports": [
      "virtual:nuxt:D:/PROJECT/blog-nuxt3/.nuxt/error-component.mjs"
    ],
    "file": "entry.2ccb60ff.js",
    "isEntry": true,
    "src": "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.js"
  },
  "entry.6f86fc6b.css": {
    "file": "entry.6f86fc6b.css",
    "resourceType": "style"
  },
  "moon.e4bb930d.svg": {
    "file": "moon.e4bb930d.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "sun.f196a66a.svg": {
    "file": "sun.f196a66a.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "icon-github-light.aff36099.svg": {
    "file": "icon-github-light.aff36099.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "icon-github-night.380c169b.svg": {
    "file": "icon-github-night.380c169b.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "pages/blogs/[blogPath].css": {
    "resourceType": "style",
    "file": "_blogPath_.6b1c59f6.css",
    "src": "pages/blogs/[blogPath].css"
  },
  "pages/blogs/[blogPath].vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "_blogPath_.c10aec2d.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.378513cd.js",
      "__commonjsHelpers.28e086c5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blogs/[blogPath].vue"
  },
  "_blogPath_.6b1c59f6.css": {
    "file": "_blogPath_.6b1c59f6.css",
    "resourceType": "style"
  },
  "pages/game/breakout.css": {
    "resourceType": "style",
    "file": "breakout.89c18acf.css",
    "src": "pages/game/breakout.css"
  },
  "pages/game/breakout.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "breakout.cfc50a67.png"
    ],
    "css": [],
    "file": "breakout.3fa08eef.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.js",
      "_phaser.888dcb6c.js",
      "__commonjsHelpers.28e086c5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/game/breakout.vue"
  },
  "breakout.89c18acf.css": {
    "file": "breakout.89c18acf.css",
    "resourceType": "style"
  },
  "breakout.cfc50a67.png": {
    "file": "breakout.cfc50a67.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "pages/game/kingandpigs.css": {
    "resourceType": "style",
    "file": "kingandpigs.42c3139b.css",
    "src": "pages/game/kingandpigs.css"
  },
  "pages/game/kingandpigs.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "Terrain(32x32).5cda6d4e.png",
      "02-KingHuman.ed4978af.png",
      "03-Pig.73ccdc30.png",
      "04-PigBox.e6f2b402.png",
      "05-PigBoom.9b30afbb.png",
      "06-PigHide.57a37b2d.png",
      "07-KingPig.7d054137.png",
      "11-Door.a4369bda.png",
      "12-Lives and Coins.f1f4bf3e.png"
    ],
    "css": [],
    "file": "kingandpigs.7b5eefae.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.js",
      "_phaser.888dcb6c.js",
      "__commonjsHelpers.28e086c5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/game/kingandpigs.vue"
  },
  "kingandpigs.42c3139b.css": {
    "file": "kingandpigs.42c3139b.css",
    "resourceType": "style"
  },
  "Terrain(32x32).5cda6d4e.png": {
    "file": "Terrain(32x32).5cda6d4e.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "02-KingHuman.ed4978af.png": {
    "file": "02-KingHuman.ed4978af.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "03-Pig.73ccdc30.png": {
    "file": "03-Pig.73ccdc30.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "04-PigBox.e6f2b402.png": {
    "file": "04-PigBox.e6f2b402.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "05-PigBoom.9b30afbb.png": {
    "file": "05-PigBoom.9b30afbb.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "06-PigHide.57a37b2d.png": {
    "file": "06-PigHide.57a37b2d.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "07-KingPig.7d054137.png": {
    "file": "07-KingPig.7d054137.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "11-Door.a4369bda.png": {
    "file": "11-Door.a4369bda.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "12-Lives and Coins.f1f4bf3e.png": {
    "file": "12-Lives and Coins.f1f4bf3e.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "pages/game/knifehit.css": {
    "resourceType": "style",
    "file": "knifehit.579d380f.css",
    "src": "pages/game/knifehit.css"
  },
  "pages/game/knifehit.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "target.5d9371ea.png",
      "knife.5bfe92d2.png"
    ],
    "css": [],
    "file": "knifehit.d7b6bad4.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.js",
      "_phaser.888dcb6c.js",
      "__commonjsHelpers.28e086c5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/game/knifehit.vue"
  },
  "knifehit.579d380f.css": {
    "file": "knifehit.579d380f.css",
    "resourceType": "style"
  },
  "target.5d9371ea.png": {
    "file": "target.5d9371ea.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "knife.5bfe92d2.png": {
    "file": "knife.5bfe92d2.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.063809d7.js",
    "imports": [
      "_nuxt-link.378513cd.js",
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "pages/three/bear.css": {
    "resourceType": "style",
    "file": "bear.3ab1d705.css",
    "src": "pages/three/bear.css"
  },
  "pages/three/bear.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "bear.d083884b.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.js",
      "_OrbitControls.b7cf5ddf.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/three/bear.vue"
  },
  "bear.3ab1d705.css": {
    "file": "bear.3ab1d705.css",
    "resourceType": "style"
  },
  "pages/three/box.css": {
    "resourceType": "style",
    "file": "box.752689c6.css",
    "src": "pages/three/box.css"
  },
  "pages/three/box.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "box.4aaa6606.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.js",
      "_OrbitControls.b7cf5ddf.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/three/box.vue"
  },
  "box.752689c6.css": {
    "file": "box.752689c6.css",
    "resourceType": "style"
  },
  "pages/three/vrhouse.css": {
    "resourceType": "style",
    "file": "vrhouse.5fee50cb.css",
    "src": "pages/three/vrhouse.css"
  },
  "pages/three/vrhouse.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "vrhouse.6288d027.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.js",
      "_OrbitControls.b7cf5ddf.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/three/vrhouse.vue"
  },
  "vrhouse.5fee50cb.css": {
    "file": "vrhouse.5fee50cb.css",
    "resourceType": "style"
  },
  "virtual:nuxt:D:/PROJECT/blog-nuxt3/.nuxt/error-component.css": {
    "resourceType": "style",
    "file": "error-component.62a04b01.css",
    "src": "virtual:nuxt:D:/PROJECT/blog-nuxt3/.nuxt/error-component.css"
  },
  "virtual:nuxt:D:/PROJECT/blog-nuxt3/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "NotFound.136cb9fe.svg"
    ],
    "css": [
      "error-component.62a04b01.css"
    ],
    "file": "error-component.15b8b555.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.3.3_sass@1.61.0/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:D:/PROJECT/blog-nuxt3/.nuxt/error-component.mjs"
  },
  "error-component.62a04b01.css": {
    "file": "error-component.62a04b01.css",
    "resourceType": "style"
  },
  "NotFound.136cb9fe.svg": {
    "file": "NotFound.136cb9fe.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
